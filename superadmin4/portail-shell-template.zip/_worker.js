// NyXia — Coque Portail universelle propre
// Même CASHFLOW_KV, même D1 centrale, aucune logique d'un portail précis.
const PORTAL_CONFIG_B64='__PORTAL_CONFIG_B64__';
const SESSION_TTL=60*60*12;
const MODEL='deepseek/deepseek-v3.2', FALLBACK='mistralai/mistral-small-3.2-24b-instruct';
function json(d,s=200,h={}){return new Response(JSON.stringify(d),{status:s,headers:{'Content-Type':'application/json; charset=utf-8',...h}})}
function cfg(){const f={id:'portail',title:'Portail NyXia',shortTitle:'Portail',mission:'',agents:[],activeAgents:[]};try{const raw=PORTAL_CONFIG_B64;if(!raw||raw.length<8)return f;const b=Uint8Array.from(atob(raw),c=>c.charCodeAt(0));return Object.assign(f,JSON.parse(new TextDecoder().decode(b)))}catch(_){return f}}
const PORTAL=cfg(); const ACTIVE=new Set((PORTAL.activeAgents||[]).map(x=>String(x).toLowerCase())); const MAP=Object.fromEntries((PORTAL.agents||[]).map(a=>[String(a.key||'').toLowerCase(),a]));
const norm=v=>String(v||'').trim().toLowerCase(); const safe=(v,n=20000)=>String(v==null?'':v).slice(0,n); const portalSlug=env=>norm((env&&(env.PORTAIL||env.PORTAL_SLUG))||PORTAL.id||'portail');
function agent(k){return MAP[norm(k)]||null} function token(){return crypto.randomUUID()+crypto.randomUUID()}
async function hashPassword(password,salt){const e=new TextEncoder(),m=await crypto.subtle.importKey('raw',e.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:e.encode(salt),iterations:100000,hash:'SHA-256'},m,256);return [...new Uint8Array(bits)].map(b=>b.toString(16).padStart(2,'0')).join('')}
async function session(t,env){if(!t||!env.CASHFLOW_KV)return null;const r=await env.CASHFLOW_KV.get('session:'+t);if(!r)return null;try{return JSON.parse(r)}catch(_){return null}}
async function login(req,env){const b=await req.json().catch(()=>({})),email=norm(b.email),pw=String(b.password||'');if(!email||!pw)return json({error:'Courriel et mot de passe requis.'},400);const raw=await env.CASHFLOW_KV.get('client:'+email);if(raw){try{const c=JSON.parse(raw);if(await hashPassword(pw,c.salt)===c.passwordHash){const t=token(),s={email:c.email||email,firstname:c.firstName||c.name||''};await env.CASHFLOW_KV.put('session:'+t,JSON.stringify(s),{expirationTtl:SESSION_TTL});return json({success:true,token:t,firstname:s.firstname})}}catch(_){}}return json({error:'Courriel ou mot de passe incorrect.'},401)}
async function check(req,env){const b=await req.json().catch(()=>({})),s=await session(b.token,env);return s?json({valid:true,email:s.email||'',firstname:s.firstname||'',portal:PORTAL.id,portal_access:true}):json({valid:false})}
async function logout(req,env){const b=await req.json().catch(()=>({}));if(b.token&&env.CASHFLOW_KV)await env.CASHFLOW_KV.delete('session:'+b.token);return json({success:true})}
async function listFormations(env,key){if(!env.CASHFLOW_KV)return[];const out=[];for(const prefix of ['formation:'+portalSlug(env)+':'+key+':','formation:'+key+':']){let cur;do{const l=await env.CASHFLOW_KV.list({prefix,cursor:cur});for(const x of l.keys||[]){const r=await env.CASHFLOW_KV.get(x.name);try{if(r)out.push(JSON.parse(r))}catch(_){}}cur=l.list_complete?null:l.cursor}while(cur);if(out.length)break}return out}
async function formationList(req,env){const u=new URL(req.url),t=u.searchParams.get('token')||'',key=norm(u.searchParams.get('agent')),s=await session(t,env);if(!s)return json({error:'Session expirée.'},401);const fs=await listFormations(env,key),p=await env.CASHFLOW_KV.get('formation_progress:'+portalSlug(env)+':'+norm(s.email));return json({formations:fs,hasProgress:!!p})}
async function retrieveBrain(env,key,q){const index=env.VECTORIZE_INDEX||env.VECTORIZE;if(!env.AI||!index||!q)return'';try{const emb=await env.AI.run('@cf/baai/bge-m3',{text:[q.slice(0,8000)]});const r=await index.query(emb.data[0],{topK:6,namespace:key,returnMetadata:true});return (r.matches||[]).map(m=>m.metadata&&m.metadata.texte_original).filter(Boolean).join('\n\n')}catch(_){return''}}
async function sharedProfile(env,key){if(!env.CASHFLOW_KV)return{};try{const r=await env.CASHFLOW_KV.get('nyxia:personnage-profil:'+key);return r?JSON.parse(r):{}}catch(_){return{}}}
function urls(s){return new Set((String(s||'').match(/https:\/\/[^\s\]\[()<>"']+/g)||[]).map(x=>x.replace(/[.,;!?]+$/,'')))}
function sanitizeMedia(s,allowed){return String(s||'').replace(/\[(VIDEO|AUDIO|IMAGE|PDF|LINK|CANVA)\s*:\s*([^\]\r\n]+)\]/gi,(m,k,p)=>{const u=String(p).split('|')[0].trim();return allowed.has(u)?m:''}).replace(/\[IMAGE_GENERATE\s*:\s*([^\]]+)\]/gi,'[IMAGE_GENERATE: $1]')}
function resourceContext(profile){
  const rows=Array.isArray(profile&&profile.resources)?profile.resources:[];
  if(!rows.length)return'';
  const out=[];
  for(const r of rows){
    const type=String(r.type||'LINK').toUpperCase();
    const title=String(r.title||'Ressource').trim();
    const url=String(r.url||'').trim();
    const button=String(r.buttonLabel||title||'Ouvrir').trim();
    const usage=String(r.usage||'').trim();
    const prompt=String(r.prompt||'').trim();
    const auto=r.autoShare!==false;
    if(type==='IMAGE_GENERATE'){
      if(!prompt)continue;
      out.push('- IMAGE IA « '+title+' » | déclencheur: '+(usage||'quand pertinent')+' | '+(auto?'peut être proposée spontanément':'seulement sur demande')+' | utilise exactement [IMAGE_GENERATE: '+prompt+']');
    }else{
      if(!/^https:\/\//i.test(url))continue;
      const marker=type==='CANVA'?'CANVA':(['VIDEO','AUDIO','IMAGE','PDF','LINK'].includes(type)?type:'LINK');
      out.push('- '+marker+' « '+title+' » | bouton: '+button+' | déclencheur: '+(usage||'quand pertinent')+' | '+(auto?'peut être proposée spontanément':'seulement sur demande')+' | URL: '+url+' | format: ['+marker+': '+url+'|'+button+']');
    }
  }
  return out.join('\n');
}

function systemPrompt(meta,profile){let p=`Tu es ${meta.name||meta.key}, un personnage de l’univers NyXia. ${meta.sub||''}.`;const role=profile.prompt||meta.prompt||'',pers=profile.personality||meta.personality||'';if(role)p+='\n\nMISSION ET PROMPT DU PERSONNAGE :\n'+role;if(pers)p+='\n\nPERSONNALITÉ :\n'+pers;p+=`\n\nPortail : ${PORTAL.title}. Mission du portail : ${PORTAL.mission||''}.`;p+='\n\nTu tutoies. Tu restes fidèle aux ressources réelles. Tu n’inventes jamais de prix, lien, fichier ou outil.';p+='\n\nMÉDIAS AUTORISÉS : [VIDEO: URL], [AUDIO: URL], [IMAGE: URL], [PDF: URL|Titre], [LINK: URL|Titre], [CANVA: URL|Titre]. Pour demander au chat de générer une image Pollinations, utilise [IMAGE_GENERATE: description]. N’invente jamais une URL.';p+='\n\nTous les personnages sont reliés à la Formation Vivante de leur portail.';return p}
async function call(env,messages,model){const k=env.OPENROUTER_API_KEY||env.AI_API_KEY;if(!k)return null;return fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+k,'HTTP-Referer':env.SITE_URL||'https://nyxia.top','X-Title':'NyXia — '+PORTAL.title},body:JSON.stringify({model,messages,max_tokens:12000,reasoning:{enabled:false}})})}
async function chat(req,env){const b=await req.json().catch(()=>({})),key=norm(b.agent),msg=safe(b.message),s=await session(b.token,env);if(!s)return json({error:'Session expirée. Reconnecte-toi.'},401);if(!ACTIVE.has(key)||!agent(key))return json({error:'Personnage non disponible dans ce portail.'},403);const meta=agent(key),profile=await sharedProfile(env,key),brain=await retrieveBrain(env,key,msg),forms=await listFormations(env,key);let bank='';try{bank=await env.CASHFLOW_KV.get('prompts:'+portalSlug(env)+':'+key)||await env.CASHFLOW_KV.get('prompts:'+key)||''}catch(_){}const resourceBank=resourceContext(profile);let sys=systemPrompt(meta,profile);if(bank)sys+='\n\nRESSOURCES CENTRALES :\n'+bank;if(resourceBank)sys+='\n\nOBJETS ET RESSOURCES AUTORISÉS DE CE PERSONNAGE :\n'+resourceBank+'\n\nUtilise seulement ces ressources quand leur déclencheur correspond. Respecte le texte de bouton configuré. Les ressources marquées seulement sur demande ne doivent pas être proposées spontanément.';if(brain)sys+='\n\nMÉMOIRE VECTORISÉE :\n'+brain;if(forms.length)sys+='\n\nFormation Vivante disponible : '+forms.map(f=>f.titre).filter(Boolean).join(' · ')+'.';const approved=urls(bank+'\n'+brain+'\n'+msg+'\n'+resourceBank);const hist=Array.isArray(b.history)?b.history.slice(-14):[];const messages=[{role:'system',content:sys},...hist.map(x=>({role:x.role==='assistant'?'assistant':'user',content:safe(x.content)})),{role:'user',content:msg}];const primary=String(profile.modelPrimary||meta.modelPrimary||MODEL).trim()||MODEL;const fallback=String(profile.modelFallback||meta.modelFallback||FALLBACK).trim()||FALLBACK;let r=await call(env,messages,primary);if(!r)return json({error:'OPENROUTER_API_KEY non configurée.'},500);if(!r.ok&&fallback&&fallback!==primary)r=await call(env,messages,fallback);if(!r||!r.ok)return json({error:'Le modèle IA est momentanément indisponible.'},502);const d=await r.json().catch(()=>({}));let c=d.choices?.[0]?.message?.content||'';c=sanitizeMedia(c,approved);return json({content:c||'Petite interruption… réessaie dans un instant 💜',model:primary})}
async function sha(s){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function tts(req,env){const b=await req.json().catch(()=>({})),s=await session(b.token,env),key=norm(b.agent);if(!s)return json({error:'Session expirée.'},401);const meta=agent(key);if(!meta)return json({error:'Personnage non disponible.'},404);const voice=String(meta.voiceId||env[meta.voiceEnv||('ELEVENLABS_'+key.toUpperCase().replace(/[^A-Z0-9]+/g,'_')+'_VOICE_ID')]||'').trim();if(!voice)return json({error:'Voix non configurée.'},404);if(!env.ELEVENLABS_API_KEY)return json({error:'ELEVENLABS_API_KEY non configurée.'},500);const clean=String(b.text||'').replace(/\[(VIDEO|AUDIO|IMAGE|PDF|LINK|CANVA|IMAGE_GENERATE)\s*:[^\]]+\]/gi,'').slice(0,4500);const ck='tts_cache_elevenlabs:'+key+':'+await sha(clean),cached=await env.CASHFLOW_KV.get(ck,'arrayBuffer');if(cached)return json({success:true,proxyUrl:'/api/tts/cached-audio?key='+encodeURIComponent(ck)+'&token='+encodeURIComponent(b.token)});const r=await fetch('https://api.elevenlabs.io/v1/text-to-speech/'+encodeURIComponent(voice),{method:'POST',headers:{'xi-api-key':env.ELEVENLABS_API_KEY,'Content-Type':'application/json','Accept':'audio/mpeg'},body:JSON.stringify({text:clean,model_id:'eleven_multilingual_v2'})});if(!r.ok)return json({error:'ElevenLabs indisponible.'},502);const audio=await r.arrayBuffer();await env.CASHFLOW_KV.put(ck,audio,{expirationTtl:2592000});return json({success:true,proxyUrl:'/api/tts/cached-audio?key='+encodeURIComponent(ck)+'&token='+encodeURIComponent(b.token)})}
async function cached(req,env){const u=new URL(req.url),s=await session(u.searchParams.get('token'),env),k=u.searchParams.get('key');if(!s||!k)return new Response('Unauthorized',{status:401});const b=await env.CASHFLOW_KV.get(k,'arrayBuffer');return b?new Response(b,{headers:{'Content-Type':'audio/mpeg'}}):new Response('Not found',{status:404})}

function msgPortal(env){return portalSlug(env)}
function msgThreadId(a,b){return [norm(a),norm(b)].sort().join('::')}
function msgThreadKey(env,a,b){return 'portalmsg:thread:'+msgPortal(env)+':'+msgThreadId(a,b)}
function msgIndexKey(env,email){return 'portalmsg:index:'+msgPortal(env)+':'+norm(email)}
async function msgIndex(env,email){try{return JSON.parse(await env.CASHFLOW_KV.get(msgIndexKey(env,email))||'[]')}catch(_){return[]}}
async function saveMsgIndex(env,email,rows){await env.CASHFLOW_KV.put(msgIndexKey(env,email),JSON.stringify(rows.slice(0,100)))}
async function messagesThreads(req,env){
  const u=new URL(req.url),s=await session(u.searchParams.get('token'),env);if(!s)return json({error:'Session expirée.'},401);
  const rows=await msgIndex(env,s.email);return json({me:norm(s.email),threads:rows.sort((a,b)=>String(b.ts||'').localeCompare(String(a.ts||'')))})
}
async function messagesThread(req,env){
  const u=new URL(req.url),s=await session(u.searchParams.get('token'),env);if(!s)return json({error:'Session expirée.'},401);
  const other=norm(u.searchParams.get('with'));if(!other)return json({error:'Destinataire requis.'},400);
  try{const rows=JSON.parse(await env.CASHFLOW_KV.get(msgThreadKey(env,s.email,other))||'[]');return json({messages:rows.slice(-300)})}catch(_){return json({messages:[]})}
}
async function messagesSend(req,env){
  const b=await req.json().catch(()=>({})),s=await session(b.token,env);if(!s)return json({error:'Session expirée.'},401);
  const from=norm(s.email),to=norm(b.to),text=safe(b.text,5000).trim();if(!to||!text)return json({error:'Destinataire et message requis.'},400);if(from===to)return json({error:'Choisis un autre destinataire.'},400);
  const key=msgThreadKey(env,from,to);let rows=[];try{rows=JSON.parse(await env.CASHFLOW_KV.get(key)||'[]')}catch(_){}
  const m={id:crypto.randomUUID(),from,to,text,ts:new Date().toISOString()};rows.push(m);rows=rows.slice(-300);await env.CASHFLOW_KV.put(key,JSON.stringify(rows));
  for(const [owner,other] of [[from,to],[to,from]]){
    let idx=await msgIndex(env,owner);idx=idx.filter(x=>x.with!==other);idx.unshift({with:other,name:other,preview:text.slice(0,100),ts:m.ts});await saveMsgIndex(env,owner,idx)
  }
  return json({ok:true,message:m})
}
async function mediaKeys(env){
  const get=async k=>String(await env.CASHFLOW_KV.get('nyxia:media-api:'+k)||'').trim();
  return{pixabay:await get('pixabay'),pexels:await get('pexels'),freesound:await get('freesound')}
}
function mediaItem(kind,title,url,preview,thumb,page){return{kind,title:title||'Ressource',url:url||preview||page||'',preview:preview||url||'',thumb:thumb||'',page:page||url||''}}
async function mediaSearch(req,env){
  const u=new URL(req.url),s=await session(u.searchParams.get('token'),env);if(!s)return json({error:'Session expirée.'},401);
  const q=String(u.searchParams.get('q')||'').trim(),provider=String(u.searchParams.get('provider')||'pixabay-images');if(!q)return json({error:'Recherche requise.'},400);
  const keys=await mediaKeys(env),items=[];let providerLabel=provider;
  if(provider==='pixabay-images'||provider==='pixabay-videos'){
    if(!keys.pixabay)return json({error:'Clé Pixabay non configurée dans Super Admin 4.'},503);
    const isVideo=provider.endsWith('videos');const endpoint=isVideo?'https://pixabay.com/api/videos/':'https://pixabay.com/api/';
    const r=await fetch(endpoint+'?key='+encodeURIComponent(keys.pixabay)+'&q='+encodeURIComponent(q)+'&per_page=24&safesearch=true'+(isVideo?'':'&image_type=photo'));
    const d=await r.json().catch(()=>({}));
    for(const x of d.hits||[]){
      if(isVideo){const v=x.videos?.medium||x.videos?.small||x.videos?.tiny||{};items.push(mediaItem('video',x.tags,v.url,v.url,x.userImageURL||'',x.pageURL))}
      else items.push(mediaItem('image',x.tags,x.largeImageURL||x.webformatURL,x.webformatURL,x.previewURL,x.pageURL))
    }providerLabel=isVideo?'Pixabay Vidéos':'Pixabay Images'
  }else if(provider==='pexels-images'||provider==='pexels-videos'){
    if(!keys.pexels)return json({error:'Clé Pexels non configurée dans Super Admin 4.'},503);
    const isVideo=provider.endsWith('videos');const endpoint=isVideo?'https://api.pexels.com/videos/search':'https://api.pexels.com/v1/search';
    const r=await fetch(endpoint+'?query='+encodeURIComponent(q)+'&per_page=24',{headers:{Authorization:keys.pexels}});const d=await r.json().catch(()=>({}));
    if(isVideo){for(const x of d.videos||[]){const f=(x.video_files||[]).filter(v=>v.link).sort((a,b)=>(a.width||0)-(b.width||0)).pop()||{};items.push(mediaItem('video',x.user?.name||'Vidéo Pexels',f.link,f.link,x.image,x.url))}}
    else{for(const x of d.photos||[])items.push(mediaItem('image',x.alt||x.photographer,x.src?.original||x.src?.large,x.src?.large,x.src?.medium,x.url))}
    providerLabel=isVideo?'Pexels Vidéos':'Pexels Images'
  }else if(provider==='freesound'){
    if(!keys.freesound)return json({error:'Clé Freesound non configurée dans Super Admin 4.'},503);
    const r=await fetch('https://freesound.org/apiv2/search/text/?query='+encodeURIComponent(q)+'&page_size=24&fields=id,name,previews,url,duration,username',{headers:{Authorization:'Token '+keys.freesound}});const d=await r.json().catch(()=>({}));
    for(const x of d.results||[])items.push(mediaItem('audio',x.name,x.previews?.['preview-hq-mp3']||x.previews?.['preview-lq-mp3'],x.previews?.['preview-hq-mp3']||x.previews?.['preview-lq-mp3'],'',x.url));providerLabel='Freesound'
  }else return json({error:'Banque inconnue.'},400);
  return json({provider,providerLabel,items})
}

export default{async fetch(request,env){const u=new URL(request.url),p=u.pathname;try{if(p==='/api/login'&&request.method==='POST')return login(request,env);if(p==='/api/check-auth'&&request.method==='POST')return check(request,env);if(p==='/api/logout'&&request.method==='POST')return logout(request,env);if(p==='/api/chat'&&request.method==='POST')return chat(request,env);if(p==='/api/formation/list'&&request.method==='GET')return formationList(request,env);if(p==='/api/tts/nyxia'&&request.method==='POST')return tts(request,env);if(p==='/api/tts/cached-audio'&&request.method==='GET')return cached(request,env);if(p==='/api/messages/threads'&&request.method==='GET')return messagesThreads(request,env);if(p==='/api/messages/thread'&&request.method==='GET')return messagesThread(request,env);if(p==='/api/messages/send'&&request.method==='POST')return messagesSend(request,env);if(p==='/api/media/search'&&request.method==='GET')return mediaSearch(request,env)}catch(e){return json({error:'Erreur serveur.',detail:String(e?.message||e)},500)}if(env.ASSETS){if(p==='/'||p==='')return env.ASSETS.fetch(new Request(new URL('/index.html',request.url),request));if(p==='/login')return env.ASSETS.fetch(new Request(new URL('/login.html',request.url),request));if(p==='/dashboard'||p==='/dashbord')return env.ASSETS.fetch(new Request(new URL('/dashbord.html',request.url),request));return env.ASSETS.fetch(request)}return new Response('Not found',{status:404})}};