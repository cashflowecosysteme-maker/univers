// NyXia — Coque Portail universelle V2
const PORTAL_CONFIG_B64='__PORTAL_CONFIG_B64__';
const SESSION_TTL=60*60*12;
const DEFAULT_MODEL='deepseek/deepseek-v3.2';
const FALLBACK_MODEL='mistralai/mistral-small-3.2-24b-instruct';
const DG_PERMANENT_KEY='univers:access:permanent';
const DG_GRANT_PREFIX='univers:access:grant:';

function json(d,s=200,h={}){return new Response(JSON.stringify(d),{status:s,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...h}})}
function cfg(){try{const b=Uint8Array.from(atob(PORTAL_CONFIG_B64),c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(b))}catch(_){return{id:'portail',title:'Portail NyXia',shortTitle:'Portail',mission:'',activeAgents:[],agents:[]}}}
const PORTAL=cfg(),AGENTS=Object.fromEntries((PORTAL.agents||[]).map(a=>[String(a.key||'').toLowerCase(),a])),ACTIVE=new Set(PORTAL.activeAgents||[]);
const norm=v=>String(v||'').trim().toLowerCase(),tok=()=>crypto.randomUUID()+crypto.randomUUID();
async function session(env,t){if(!t)return null;const r=await env.CASHFLOW_KV.get('portal:session:'+t);if(!r)return null;try{return JSON.parse(r)}catch(_){return null}}
function cookieValue(req,name){const raw=req.headers.get('Cookie')||'';for(const part of raw.split(';')){const i=part.indexOf('=');if(i<0)continue;if(part.slice(0,i).trim()===name)return decodeURIComponent(part.slice(i+1).trim())}return''}
function sessionCookie(token,maxAge=SESSION_TTL){return 'nyxia_portal_session='+encodeURIComponent(token)+'; Path=/; Max-Age='+maxAge+'; HttpOnly; Secure; SameSite=Lax'}
function clearSessionCookie(){return 'nyxia_portal_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax'}
async function browserSession(req,env){return session(env,cookieValue(req,'nyxia_portal_session'))}
function loginRedirect(req){const u=new URL('/login.html',req.url);return Response.redirect(u.toString(),302)}
function isProtectedHtml(path){if(path==='/'||path===''||path==='/index.html'||path==='/login.html'||path==='/login')return false;return /\.html$/i.test(path)}

async function checkAccess(env,email){
 email=norm(email);if(!email)return{allowed:false};
 const per=await env.CASHFLOW_KV.get(DG_PERMANENT_KEY);try{for(const p of JSON.parse(per||'[]'))if(norm(p.email)===email&&(p.allPortals||(p.portalIds||[]).includes(PORTAL.id)))return{allowed:true,type:'permanent'}}catch(_){}
 const c=await env.CASHFLOW_KV.get('client:'+email);try{const u=JSON.parse(c||'{}');if(u.active!==false&&(u.products||[]).map(norm).includes(norm(PORTAL.id)))return{allowed:true,type:'purchased'}}catch(_){}
 const prefix=DG_GRANT_PREFIX+encodeURIComponent(email)+':';let cur;do{const l=await env.CASHFLOW_KV.list({prefix,cursor:cur});for(const k of l.keys||[]){const r=await env.CASHFLOW_KV.get(k.name);try{const g=JSON.parse(r||'{}');if(g.portalId===PORTAL.id&&g.expiresAt&&Date.parse(g.expiresAt)>Date.now())return{allowed:true,type:'temporary',expiresAt:g.expiresAt}}catch(_){}}cur=l.list_complete?null:l.cursor}while(cur);
 return{allowed:false}
}
async function login(req,env){const b=await req.json().catch(()=>({})),email=norm(b.email),password=String(b.password||''),submittedFirstname=String(b.firstname||'').trim();if(!email)return json({error:'Courriel requis.'},400);
 const access=await checkAccess(env,email);if(!access.allowed)return json({error:'Aucun accès actif à ce portail.'},403);
 const cr=await env.CASHFLOW_KV.get('client:'+email);let client={email};try{client={...client,...JSON.parse(cr||'{}')}}catch(_){}
 if(client.password&&password!==client.password)return json({error:'Mot de passe incorrect.'},401);
 const firstname=String(submittedFirstname||client.firstname||client.firstName||'').trim();if(!firstname)return json({error:'Prénom requis.'},400);
 const t=tok(),s={email,firstname,portal:PORTAL.id,accessType:access.type,expiresAt:access.expiresAt||null};await env.CASHFLOW_KV.put('portal:session:'+t,JSON.stringify(s),{expirationTtl:SESSION_TTL});return json({success:true,token:t,firstname:s.firstname,user:s},200,{'Set-Cookie':sessionCookie(t)})
}
async function logout(req,env){let t='';try{const b=await req.json();t=String(b.token||'')}catch(_){}if(!t)t=cookieValue(req,'nyxia_portal_session');if(t){try{await env.CASHFLOW_KV.delete('portal:session:'+t)}catch(_){}}return json({success:true},200,{'Set-Cookie':clearSessionCookie()})}
async function requireSession(req,env){const u=new URL(req.url);let t=u.searchParams.get('token')||u.searchParams.get('t')||'';if(req.method!=='GET'){try{const c=req.clone();const b=await c.json();t=b.token||t}catch(_){}}return session(env,t)}
async function retrieve(env,agent,q){if(!env.AI||!env.VECTORIZE_INDEX||!q)return'';try{const e=await env.AI.run('@cf/baai/bge-m3',{text:[q]}),r=await env.VECTORIZE_INDEX.query(e.data[0],{topK:6,returnMetadata:'all',namespace:agent});return(r.matches||[]).filter(x=>x.score>.35).map(x=>x.metadata?.texte_original||'').filter(Boolean).join('\n\n---\n\n')}catch(_){return''}}
async function formations(env,agent){
 const out=[];
 const agentKey=norm(agent);
 const profile=AGENTS[agentKey]||{};
 const configuredPortal=norm(profile.primaryPortal||profile.portail||'');
 const sourcePortal=(configuredPortal&&configuredPortal!=='tous')?configuredPortal:norm(PORTAL.id);
 const prefix='formation:'+sourcePortal+':'+agentKey+':';
 let cur;
 do{
  const l=await env.CASHFLOW_KV.list({prefix,cursor:cur});
  for(const k of l.keys||[]){
   try{
    const d=JSON.parse(await env.CASHFLOW_KV.get(k.name)||'{}');
    if(!d||!d.id)continue;
    if(d.agent&&norm(d.agent)!==agentKey)continue;
    if(d.portail&&norm(d.portail)!==sourcePortal)continue;
    out.push(d);
   }catch(_){}
  }
  cur=l.list_complete?null:l.cursor;
 }while(cur);
 out.sort((a,b)=>(a.ordre||0)-(b.ordre||0)||String(a.titre||'').localeCompare(String(b.titre||'')));
 return out;
}
function renderBlock(b,first){const t=String(b?.type||'texte').toLowerCase();if(t==='texte'||t==='intervention')return String(b.contenu||'').replace(/\{prenom\}/gi,first||'toi');if(t==='exercice')return['🎯 '+(b.objectif||''),b.consigne||''].filter(Boolean).join('\n\n');if(t==='image')return (b.legende?b.legende+'\n':'')+'[IMAGE: '+b.url+']';if(t==='audio')return (b.intro?b.intro+'\n':'')+'[AUDIO: '+b.url+'|'+(b.titre||'Audio')+']';if(t==='video'||t==='vidéo')return (b.intro?b.intro+'\n':'')+'[VIDEO: '+b.url+'|'+(b.titre||'Vidéo')+']';if(t==='lien')return (b.intro?b.intro+'\n':'')+'[LINK: '+b.url+'|'+(b.titre||'Ouvrir')+']';return''}
async function formationTurn(env,s,agent,msg){const n=norm(msg).normalize('NFD').replace(/[\u0300-\u036f]/g,'');if(!/(formation|cours|suite|continue|reprend)/.test(n))return null;const fs=await formations(env,agent);if(!fs.length)return null;const f=fs[0],mods=f.modules||[];if(!mods.length)return{content:'Cette formation n’a pas encore de module.'};const key='formation-progress:'+PORTAL.id+':'+s.email+':'+agent;let st={mi:0,bi:0};try{st={...st,...JSON.parse(await env.CASHFLOW_KV.get(key)||'{}')}}catch(_){}
 if(/suite|continue|reprend/.test(n)&&st.started)st.bi++;else st.started=true;while(st.mi<mods.length&&st.bi>=(mods[st.mi].blocs||[]).length){st.mi++;st.bi=0}if(st.mi>=mods.length)return{content:'✨ Tu as terminé « '+(f.titre||'la formation')+' ».'};const m=mods[st.mi],b=(m.blocs||[])[st.bi];await env.CASHFLOW_KV.put(key,JSON.stringify(st));return{content:'🎓 **'+(f.titre||'Formation')+' — Module '+(m.numero||st.mi+1)+' · '+(m.titre||'')+'**\n\n'+renderBlock(b,s.firstname)+'\n\n— Quand tu es prête, dis-moi « suite ».'}}

function sanitizeAssistantContent(content){
 const fallback='Je suis là avec toi. Dis-moi ce que tu veux faire avancer.';
 let s=String(content||'').trim();
 if(!s)return fallback;
 s=s
  .replace(/\[(?:VIDEO|AUDIO|PDF|LINK|PHOTO)\s*:[^\]]+\]/gi,'')
  .replace(/\[[^\]]+\]\((https?:\/\/[^\s)]+)\)/gi,'')
  .replace(/https?:\/\/[^\s<]+/gi,'')
  .replace(/\n{3,}/g,'\n\n')
  .trim();
 return s||fallback;
}

async function openrouter(env,messages,model){const r=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+env.OPENROUTER_API_KEY,'HTTP-Referer':'https://nyxia.top','X-Title':'NyXia Portail'},body:JSON.stringify({model:model||DEFAULT_MODEL,messages,max_tokens:900,temperature:.72})});if(!r.ok)throw Error('OpenRouter '+r.status);const d=await r.json();return d.choices?.[0]?.message?.content?.trim()||''}
async function chat(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const key=norm(b.agent),a=AGENTS[key];if(!a||!ACTIVE.has(key))return json({error:'Personnage indisponible.'},403);
 const ft=await formationTurn(env,s,key,b.message||'');if(ft)return json(ft);
 const brain=await retrieve(env,a.vectorNamespace||key,b.message||'');let imageInfo='';if(b.attachment?.dataUrl)imageInfo='\nLa personne a joint une image nommée '+String(b.attachment.name||'image')+'.';
 const sys=`Tu es ${a.name||key}, personnage de l’univers NyXia dans le portail « ${PORTAL.title} ».
Rôle : ${a.sub||a.visibleRole||''}
Mission : ${a.mission||a.prompt||''}
Personnalité : ${a.personality||''}
Style : ${a.tone||a.languageStyle||''}
Tu réponds en français naturel. Tu restes fidèle à ton identité et à la mission de ce portail.
Tu n’inventes jamais de PDF, vidéo, audio, lien ou URL. Tu n’envoies aucun média spontané et tu ne simules jamais une ressource inexistante. Si une ressource n’est pas réellement configurée dans le portail, tu n’en parles pas comme si elle existait. Si la personne veut une image, réponds naturellement sans inventer de lien : le portail gère la création d’image via le bouton 🎨 ou une demande explicite.
${brain?'\nConnaissances pertinentes :\n'+brain:''}${imageInfo}`;
 const messages=[{role:'system',content:sys},...(Array.isArray(b.history)?b.history.slice(-14):[]),{role:'user',content:String(b.message||'')}];
 let content;try{content=await openrouter(env,messages,a.modelPrimary||DEFAULT_MODEL)}catch(_){content=await openrouter(env,messages,a.modelFallback||FALLBACK_MODEL)}content=sanitizeAssistantContent(content);return json({content})}
async function imageGenerate(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const p=String(b.prompt||'').trim();if(!p)return json({error:'Décris l’image à créer.'},400);
 const apiKey=String(env.AIMLAPI_CREATOR_KEY||'');if(!apiKey)return json({error:'Aucune clé AIMLAPI n’est configurée pour ce portail.'},500);const agent=AGENTS[norm(b.agent)]||{};
 const style=[p,'esthétique élégante NyXia','haute qualité','sans texte sauf demandé explicitement'];if(agent.name)style.push('cohérent avec l’univers de '+agent.name);
 const payload={model:'flux/schnell',prompt:style.join(', '),num_images:1,image_size:String(b.format||'square_hd'),enable_safety_checker:true};
 const r=await fetch('https://api.aimlapi.com/v1/images/generations',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+apiKey},body:JSON.stringify(payload)});
 if(!r.ok){const txt=await r.text().catch(()=> '');return json({error:'Génération d’image indisponible pour le moment.',details:txt.slice(0,240)},502)}
 const d=await r.json().catch(()=>({}));let url='';const first=Array.isArray(d.data)&&d.data[0]?d.data[0]:null;
 if(first){if(first.url)url=String(first.url);else if(first.b64_json)url='data:image/png;base64,'+String(first.b64_json);else if(first.b64)url='data:image/png;base64,'+String(first.b64)}
 if(!url&&d.url)url=String(d.url);if(!url&&d.b64_json)url='data:image/png;base64,'+String(d.b64_json);if(!url)return json({error:'Aucune image valide n’a été retournée par AIMLAPI.'},502);
 return json({url,caption:'Voici l’image que j’ai créée pour toi.'})}
async function tts(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const a=AGENTS[norm(b.agent)]||{},voice=String(a.voiceId||'');if(!voice||!env.ELEVENLABS_API_KEY)return json({error:'Voix non configurée.'},404);const r=await fetch('https://api.elevenlabs.io/v1/text-to-speech/'+encodeURIComponent(voice),{method:'POST',headers:{'xi-api-key':env.ELEVENLABS_API_KEY,'Content-Type':'application/json','Accept':'audio/mpeg'},body:JSON.stringify({text:String(b.text||'').slice(0,4500),model_id:'eleven_multilingual_v2'})});if(!r.ok)return json({error:'Voix indisponible.'},502);return new Response(await r.arrayBuffer(),{headers:{'Content-Type':'audio/mpeg'}})}
function mediaFormatSize(format){if(format==='portrait')return{orientation:'portrait',pixabayOrientation:'vertical'};if(format==='landscape')return{orientation:'landscape',pixabayOrientation:'horizontal'};return{orientation:'',pixabayOrientation:'all'}}
async function searchImages(env,q,format){
 const results=[],seen=new Set(),fmt=mediaFormatSize(format);
 const add=x=>{const k=x&&x.downloadUrl;if(!k||seen.has(k))return;seen.add(k);results.push(x)}
 const pexels=String(env.PEXELS_KEY||'');
 if(pexels){
  try{
   let url='https://api.pexels.com/v1/search?per_page=18&query='+encodeURIComponent(q);
   if(fmt.orientation)url+='&orientation='+fmt.orientation;
   const r=await fetch(url,{headers:{Authorization:pexels}}),d=await r.json();
   for(const p of d.photos||[])add({type:'image',provider:'Pexels',previewUrl:p.src?.medium||p.src?.small,downloadUrl:p.src?.original||p.src?.large2x||p.src?.large});
  }catch(_){}
 }
 const pix=String(env.PIXABAY_KEY_IMAGES||'');
 if(pix){
  try{
   const url='https://pixabay.com/api/?key='+encodeURIComponent(pix)+'&q='+encodeURIComponent(q)+'&per_page=18&safesearch=true&orientation='+fmt.pixabayOrientation;
   const r=await fetch(url),d=await r.json();
   for(const p of d.hits||[])add({type:'image',provider:'Pixabay',previewUrl:p.webformatURL||p.previewURL,downloadUrl:p.largeImageURL||p.webformatURL});
  }catch(_){}
 }
 const unsplash=String(env.UNSPLASH_ACCES_KEY||'');
 if(unsplash){
  try{
   let url='https://api.unsplash.com/search/photos?per_page=18&query='+encodeURIComponent(q);
   if(fmt.orientation)url+='&orientation='+fmt.orientation;
   const r=await fetch(url,{headers:{Authorization:'Client-ID '+unsplash}}),d=await r.json();
   for(const p of d.results||[])add({type:'image',provider:'Unsplash',previewUrl:p.urls?.small||p.urls?.thumb,downloadUrl:p.urls?.full||p.urls?.regular});
  }catch(_){}
 }
 return results.slice(0,36)
}
async function searchVideos(env,q){
 const results=[],seen=new Set(),add=x=>{const k=x&&x.videoUrl;if(!k||seen.has(k))return;seen.add(k);results.push(x)}
 const pexels=String(env.PEXELS_KEY||'');
 if(pexels){
  try{
   const r=await fetch('https://api.pexels.com/videos/search?per_page=12&query='+encodeURIComponent(q),{headers:{Authorization:pexels}}),d=await r.json();
   for(const v of d.videos||[]){const f=(v.video_files||[]).slice().sort((a,b)=>(b.width||0)-(a.width||0))[0];if(f)add({type:'video',provider:'Pexels',previewUrl:v.image||'',videoUrl:f.link,downloadUrl:f.link})}
  }catch(_){}
 }
 const pix=String(env.PIXABAY_KEY_VIDEO||'');
 if(pix){
  try{
   const r=await fetch('https://pixabay.com/api/videos/?key='+encodeURIComponent(pix)+'&q='+encodeURIComponent(q)+'&per_page=12&safesearch=true'),d=await r.json();
   for(const v of d.hits||[]){const f=v.videos?.medium||v.videos?.small||v.videos?.tiny||v.videos?.large;if(f)add({type:'video',provider:'Pixabay',previewUrl:v.picture_id?('https://i.vimeocdn.com/video/'+v.picture_id+'_640x360.jpg'):'',videoUrl:f.url,downloadUrl:f.url})}
  }catch(_){}
 }
 return results.slice(0,24)
}
async function searchSounds(env,q){
 const results=[];
 const key=String(env.FREESOUND_API_KEY||'');
 if(!key)return results;
 try{
  const url='https://freesound.org/apiv2/search/text/?query='+encodeURIComponent(q)+'&page_size=24&fields=id,name,previews,duration,url';
  const r=await fetch(url,{headers:{Authorization:'Token '+key}}),d=await r.json();
  for(const s of d.results||[]){const audio=s.previews?.['preview-hq-mp3']||s.previews?.['preview-lq-mp3']||s.previews?.['preview-hq-ogg'];if(audio)results.push({type:'sound',provider:'Freesound',name:s.name||'Son',duration:Math.round(Number(s.duration||0)),audioUrl:audio,downloadUrl:s.url||audio})}
 }catch(_){}
 return results
}
async function mediaImages(req,env){
 const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);
 const q=String(b.query||'').trim();if(!q)return json({results:[]});
 const images=await searchImages(env,q,String(b.format||'')),videos=await searchVideos(env,q);
 return json({results:[...images,...videos]})
}
async function mediaSounds(req,env){
 const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);
 const q=String(b.query||'').trim();if(!q)return json({results:[]});
 return json({results:await searchSounds(env,q)})
}
async function mediaSearch(req,env){
 const u=new URL(req.url),s=await session(env,u.searchParams.get('token'));if(!s)return json({error:'Session expirée.'},401);
 const q=String(u.searchParams.get('q')||'').trim();if(!q)return json({results:[]});
 return json({results:await searchImages(env,q,String(u.searchParams.get('format')||''))})
}
async function msgSend(req,env){
 const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);
 const to=String(b.to||b.toEmail||'__admin__').trim()||'__admin__';
 const id=crypto.randomUUID(),createdAt=new Date().toISOString();
 const m={id,from:s.email,fromName:s.firstname||s.email,to,subject:String(b.subject||'Message depuis '+PORTAL.shortTitle),body:String(b.body||''),createdAt,read:false,kind:to==='__admin__'?'to_admin':'direct',portal:PORTAL.title};
 await env.CASHFLOW_KV.put('message:'+to+':'+createdAt+'_'+id,JSON.stringify(m));
 return json({success:true,message:m})
}
async function msgInbox(req,env){
 const u=new URL(req.url),token=u.searchParams.get('token')||'';let s=await session(env,token);
 if(!s&&req.method!=='GET'){const b=await req.json().catch(()=>({}));s=await session(env,b.token)}
 if(!s)return json({error:'Session expirée.'},401);
 const out=[];let cur;
 do{
  const l=await env.CASHFLOW_KV.list({prefix:'message:'+s.email+':',cursor:cur});
  for(const k of l.keys||[]){try{const m=JSON.parse(await env.CASHFLOW_KV.get(k.name)||'{}');m.key=k.name;out.push(m)}catch(_){}}
  cur=l.list_complete?null:l.cursor
 }while(cur);
 out.sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')));
 return json({messages:out,unreadCount:out.filter(m=>!m.read).length})
}
async function msgContacts(req,env){
 const b=req.method==='GET'?{}:await req.json().catch(()=>({}));
 const u=new URL(req.url),s=await session(env,b.token||u.searchParams.get('token'));if(!s)return json({error:'Session expirée.'},401);
 return json({contacts:[{id:'__admin__',email:'__admin__',firstName:'Diane',name:'Diane — Super Admin'}],gardiennes:[{email:'__admin__',firstName:'Diane'}]})
}
async function msgRead(req,env){
 const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);
 const key=String(b.key||'');if(!key.startsWith('message:'+s.email+':'))return json({error:'Message invalide.'},403);
 const raw=await env.CASHFLOW_KV.get(key);if(!raw)return json({error:'Message introuvable.'},404);
 const m=JSON.parse(raw);m.read=true;await env.CASHFLOW_KV.put(key,JSON.stringify(m));return json({success:true})
}
async function msgDelete(req,env){
 const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);
 const key=String(b.key||'');if(!key.startsWith('message:'+s.email+':'))return json({error:'Message invalide.'},403);
 await env.CASHFLOW_KV.delete(key);return json({success:true})
}
async function formationList(req,env){const u=new URL(req.url),s=await session(env,u.searchParams.get('token'));if(!s)return json({error:'Session expirée.'},401);const a=norm(u.searchParams.get('agent')),fs=await formations(env,a),key='formation-progress:'+PORTAL.id+':'+s.email+':'+a;return json({formations:fs.map(f=>({id:f.id,titre:f.titre,description:f.description})),hasProgress:!!(await env.CASHFLOW_KV.get(key))})}
function staticReq(req,path){return new Request(new URL(path,req.url),req)}
export default{async fetch(req,env){const u=new URL(req.url),p=u.pathname;try{
 if(p==='/api/login'&&req.method==='POST')return login(req,env);
 if(p==='/api/logout'&&req.method==='POST')return logout(req,env);
 if(p==='/api/check-auth'){const b=await req.json().catch(()=>({})),s=await session(env,b.token);return json({valid:!!s,email:s?.email||'',firstname:s?.firstname||''})}
 if(p==='/api/chat'&&req.method==='POST')return chat(req,env);
 if((p==='/api/image/generate'||p==='/api/image')&&req.method==='POST')return imageGenerate(req,env);
 if(p==='/api/tts'&&req.method==='POST')return tts(req,env);
 if(p==='/api/media/search'&&req.method==='GET')return mediaSearch(req,env);
 if(p==='/api/media/images'&&req.method==='POST')return mediaImages(req,env);
 if(p==='/api/media/sounds'&&req.method==='POST')return mediaSounds(req,env);
 if(p==='/api/messagerie/send'&&req.method==='POST')return msgSend(req,env);
 if(p==='/api/messagerie/contacts'&&(req.method==='GET'||req.method==='POST'))return msgContacts(req,env);
 if(p==='/api/messagerie/read'&&req.method==='POST')return msgRead(req,env);
 if(p==='/api/messagerie/delete'&&req.method==='POST')return msgDelete(req,env);
 if(p==='/api/gardiennes/list'&&req.method==='POST')return msgContacts(req,env);
 if(p==='/api/messages'&&req.method==='POST')return msgInbox(req,env);
 if(p==='/api/messages/send'&&req.method==='POST')return msgSend(req,env);
 if(p==='/api/messages/read'&&req.method==='POST')return msgRead(req,env);
 if(p==='/api/messages/delete'&&req.method==='POST')return msgDelete(req,env);
 if(p==='/api/messagerie/inbox'&&(req.method==='GET'||req.method==='POST'))return msgInbox(req,env);
 if(p==='/api/formation/list'&&req.method==='GET')return formationList(req,env);
 if(p==='/api/health')return json({ok:true,portal:PORTAL.id,features:['chat','formation','messagerie','media-bank','image-generation','tts','degustation']});
 }catch(e){console.error(e);return json({error:String(e?.message||e)},500)}
 if(env.ASSETS){
  if(p==='/'||p==='')return env.ASSETS.fetch(staticReq(req,'/index.html'));
  if(p==='/login')return env.ASSETS.fetch(staticReq(req,'/login.html'));
  if(isProtectedHtml(p)){const s=await browserSession(req,env);if(!s)return loginRedirect(req)}
  return env.ASSETS.fetch(req)
 }return new Response('Not found',{status:404})}}
