// NyXia — Coque Portail universelle propre
// Même CASHFLOW_KV, même D1 centrale, aucune logique d'un portail précis.
const PORTAL_CONFIG_B64='__PORTAL_CONFIG_B64__';
const SESSION_TTL=60*60*12;
const MODEL='deepseek/deepseek-v3.2', FALLBACK='mistralai/mistral-small-3.2-24b-instruct';
function json(d,s=200,h={}){return new Response(JSON.stringify(d),{status:s,headers:{'Content-Type':'application/json; charset=utf-8',...h}})}
function cfg(){const f={id:'portail',title:'Portail NyXia',shortTitle:'Portail',mission:'',agents:[],activeAgents:[]};try{const raw=PORTAL_CONFIG_B64;if(!raw||raw.length<8)return f;const b=Uint8Array.from(atob(raw),c=>c.charCodeAt(0));return Object.assign(f,JSON.parse(new TextDecoder().decode(b)))}catch(_){return f}}
const PORTAL=cfg(); const ACTIVE=new Set((PORTAL.activeAgents||[]).map(x=>String(x).toLowerCase())); const MAP=Object.fromEntries((PORTAL.agents||[]).map(a=>[String(a.key||'').toLowerCase(),a]));
const norm=v=>String(v||'').trim().toLowerCase(); const safe=(v,n=20000)=>String(v==null?'':v).slice(0,n); const portalSlug=env=>norm((env&&(env.PORTAIL||env.PORTAL_SLUG))||PORTAL.id||'portail');
function agent(k){return MAP[norm(k)]||null} function token(){return crypto.randomUUID()+crypto.randomUUID()}
async function hashPassword(password,salt){const e=new TextEncoder(),m=await crypto.subtle.importKey('raw',e.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:e.encode(salt),iterations:100000,hash:'SHA-256'},m,256);return [...new Uint8Array(bits)].map(b=>b.toString(16).padStart(2,'0')).join('')}
async function session(t,env){if(!t||!env.CASHFLOW_KV)return null;const r=await env.CASHFLOW_KV.get('session:'+t);if(!r)return null;try{return JSON.parse(r)}catch(_){return null}}
async function login(req,env){const b=await req.json().catch(()=>({})),email=norm(b.email),pw=String(b.password||'');if(!email||!pw)return json({error:'Courriel et mot de passe requis.'},400);const raw=await env.CASHFLOW_KV.get('client:'+email);if(raw){try{const c=JSON.parse(raw);if(await hashPassword(pw,c.salt)===c.passwordHash){const t=token(),s={email:c.email||email,firstname:c.firstName||c.name||''};await env.CASHFLOW_KV.put('session:'+t,JSON.stringify(s),{expirationTtl:SESSION_TTL});return json({success:true,token:t,firstname:s.firstname})}}catch(_){}}return json({error:'Courriel ou mot de passe incorrect.'},401)}
async function check(req,env){const b=await req.json().catch(()=>({})),s=await session(b.token,env);return s?json({valid:true,email:s.email||'',firstname:s.firstname||'',portal:PORTAL.id,portal_access:true}):json({valid:false})}
async function logout(req,env){const b=await req.json().catch(()=>({}));if(b.token&&env.CASHFLOW_KV)await env.CASHFLOW_KV.delete('session:'+b.token);return json({success:true})}
async function listFormations(env,key){if(!env.CASHFLOW_KV)return[];const out=[];for(const prefix of ['formation:'+portalSlug(env)+':'+key+':','formation:'+key+':']){let cur;do{const l=await env.CASHFLOW_KV.list({prefix,cursor:cur});for(const x of l.keys||[]){const r=await env.CASHFLOW_KV.get(x.name);try{if(r)out.push(JSON.parse(r))}catch(_){}}cur=l.list_complete?null:l.cursor}while(cur);if(out.length)break}return out}
async function formationList(req,env){const u=new URL(req.url),t=u.searchParams.get('token')||'',key=norm(u.searchParams.get('agent')),s=await session(t,env);if(!s)return json({error:'Session expirée.'},401);const fs=await listFormations(env,key),p=await env.CASHFLOW_KV.get('formation_progress:'+portalSlug(env)+':'+norm(s.email));return json({formations:fs,hasProgress:!!p})}
async function retrieveBrain(env,key,q){const index=env.VECTORIZE_INDEX||env.VECTORIZE;if(!env.AI||!index||!q)return'';try{const emb=await env.AI.run('@cf/baai/bge-m3',{text:[q.slice(0,8000)]});const r=await index.query(emb.data[0],{topK:6,namespace:key,returnMetadata:true});return (r.matches||[]).map(m=>m.metadata&&m.metadata.texte_original).filter(Boolean).join('\n\n')}catch(_){return''}}
async function sharedProfile(env,key){if(!env.CASHFLOW_KV)return{};try{const r=await env.CASHFLOW_KV.get('nyxia:personnage-profil:'+key);return r?JSON.parse(r):{}}catch(_){return{}}}
function urls(s){return new Set((String(s||'').match(/https:\/\/[^\s\]\[()<>"']+/g)||[]).map(x=>x.replace(/[.,;!?]+$/,'')))}
function sanitizeMedia(s,allowed){return String(s||'').replace(/\[(VIDEO|AUDIO|IMAGE|PDF|LINK|CANVA)\s*:\s*([^\]\r\n]+)\]/gi,(m,k,p)=>{const u=String(p).split('|')[0].trim();return allowed.has(u)?m:''}).replace(/\[IMAGE_GENERATE\s*:\s*([^\]]+)\]/gi,'[IMAGE_GENERATE: $1]')}
function systemPrompt(meta,profile){let p=`Tu es ${meta.name||meta.key}, un personnage de l’univers NyXia. ${meta.sub||''}.`;const role=profile.prompt||meta.prompt||'',pers=profile.personality||meta.personality||'';if(role)p+='\n\nMISSION ET PROMPT DU PERSONNAGE :\n'+role;if(pers)p+='\n\nPERSONNALITÉ :\n'+pers;p+=`\n\nPortail : ${PORTAL.title}. Mission du portail : ${PORTAL.mission||''}.`;p+='\n\nTu tutoies. Tu restes fidèle aux ressources réelles. Tu n’inventes jamais de prix, lien, fichier ou outil.';p+='\n\nMÉDIAS AUTORISÉS : [VIDEO: URL], [AUDIO: URL], [IMAGE: URL], [PDF: URL|Titre], [LINK: URL|Titre], [CANVA: URL|Titre]. Pour demander au chat de générer une image Pollinations, utilise [IMAGE_GENERATE: description]. N’invente jamais une URL.';p+='\n\nTous les personnages sont reliés à la Formation Vivante de leur portail.';return p}
async function call(env,messages,model){const k=env.OPENROUTER_API_KEY||env.AI_API_KEY;if(!k)return null;return fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+k,'HTTP-Referer':env.SITE_URL||'https://nyxia.top','X-Title':'NyXia — '+PORTAL.title},body:JSON.stringify({model,messages,max_tokens:12000,reasoning:{enabled:false}})})}
async function chat(req,env){const b=await req.json().catch(()=>({})),key=norm(b.agent),msg=safe(b.message),s=await session(b.token,env);if(!s)return json({error:'Session expirée. Reconnecte-toi.'},401);if(!ACTIVE.has(key)||!agent(key))return json({error:'Personnage non disponible dans ce portail.'},403);const meta=agent(key),profile=await sharedProfile(env,key),brain=await retrieveBrain(env,key,msg),forms=await listFormations(env,key);let bank='';try{bank=await env.CASHFLOW_KV.get('prompts:'+portalSlug(env)+':'+key)||await env.CASHFLOW_KV.get('prompts:'+key)||''}catch(_){}let sys=systemPrompt(meta,profile);if(bank)sys+='\n\nRESSOURCES CENTRALES :\n'+bank;if(brain)sys+='\n\nMÉMOIRE VECTORISÉE :\n'+brain;if(forms.length)sys+='\n\nFormation Vivante disponible : '+forms.map(f=>f.titre).filter(Boolean).join(' · ')+'.';const approved=urls(bank+'\n'+brain+'\n'+msg);const hist=Array.isArray(b.history)?b.history.slice(-14):[];const messages=[{role:'system',content:sys},...hist.map(x=>({role:x.role==='assistant'?'assistant':'user',content:safe(x.content)})),{role:'user',content:msg}];let r=await call(env,messages,MODEL);if(!r)return json({error:'OPENROUTER_API_KEY non configurée.'},500);if(!r.ok)r=await call(env,messages,FALLBACK);if(!r||!r.ok)return json({error:'Le modèle IA est momentanément indisponible.'},502);const d=await r.json().catch(()=>({}));let c=d.choices?.[0]?.message?.content||'';c=sanitizeMedia(c,approved);return json({content:c||'Petite interruption… réessaie dans un instant 💜'})}
async function sha(s){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function tts(req,env){const b=await req.json().catch(()=>({})),s=await session(b.token,env),key=norm(b.agent);if(!s)return json({error:'Session expirée.'},401);const meta=agent(key);if(!meta)return json({error:'Personnage non disponible.'},404);const voice=String(meta.voiceId||env[meta.voiceEnv||('ELEVENLABS_'+key.toUpperCase().replace(/[^A-Z0-9]+/g,'_')+'_VOICE_ID')]||'').trim();if(!voice)return json({error:'Voix non configurée.'},404);if(!env.ELEVENLABS_API_KEY)return json({error:'ELEVENLABS_API_KEY non configurée.'},500);const clean=String(b.text||'').replace(/\[(VIDEO|AUDIO|IMAGE|PDF|LINK|CANVA|IMAGE_GENERATE)\s*:[^\]]+\]/gi,'').slice(0,4500);const ck='tts_cache_elevenlabs:'+key+':'+await sha(clean),cached=await env.CASHFLOW_KV.get(ck,'arrayBuffer');if(cached)return json({success:true,proxyUrl:'/api/tts/cached-audio?key='+encodeURIComponent(ck)+'&token='+encodeURIComponent(b.token)});const r=await fetch('https://api.elevenlabs.io/v1/text-to-speech/'+encodeURIComponent(voice),{method:'POST',headers:{'xi-api-key':env.ELEVENLABS_API_KEY,'Content-Type':'application/json','Accept':'audio/mpeg'},body:JSON.stringify({text:clean,model_id:'eleven_multilingual_v2'})});if(!r.ok)return json({error:'ElevenLabs indisponible.'},502);const audio=await r.arrayBuffer();await env.CASHFLOW_KV.put(ck,audio,{expirationTtl:2592000});return json({success:true,proxyUrl:'/api/tts/cached-audio?key='+encodeURIComponent(ck)+'&token='+encodeURIComponent(b.token)})}
async function cached(req,env){const u=new URL(req.url),s=await session(u.searchParams.get('token'),env),k=u.searchParams.get('key');if(!s||!k)return new Response('Unauthorized',{status:401});const b=await env.CASHFLOW_KV.get(k,'arrayBuffer');return b?new Response(b,{headers:{'Content-Type':'audio/mpeg'}}):new Response('Not found',{status:404})}

/* ───────────── MESSAGERIE INTERNE NYXIA ─────────────
   Même schéma CASHFLOW_KV que Studio Prompt / Super Admin 1 :
   message:__admin__:* pour les messages client -> équipe
   message:{email}:* pour les réponses équipe -> client
*/
async function portalMessageList(req,env){
  const b=await req.json().catch(()=>({})),s=await session(b.token,env);
  if(!s)return json({error:'Session expirée.'},401);
  const email=norm(s.email),messages=[];let unreadCount=0;

  let cursor;
  do{
    const l=await env.CASHFLOW_KV.list({prefix:'message:'+email+':',cursor});
    for(const k of l.keys||[]){
      const raw=await env.CASHFLOW_KV.get(k.name);if(!raw)continue;
      try{
        const m=JSON.parse(raw);m.key=k.name;m.mine=false;
        if(!m.read)unreadCount++;
        messages.push(m)
      }catch(_){}
    }
    cursor=l.list_complete?null:l.cursor
  }while(cursor);

  cursor=undefined;
  do{
    const l=await env.CASHFLOW_KV.list({prefix:'message:__admin__:',cursor});
    for(const k of l.keys||[]){
      const raw=await env.CASHFLOW_KV.get(k.name);if(!raw)continue;
      try{
        const m=JSON.parse(raw);
        if(norm(m.from)===email){
          m.key=k.name;m.mine=true;messages.push(m)
        }
      }catch(_){}
    }
    cursor=l.list_complete?null:l.cursor
  }while(cursor);

  messages.sort((a,b)=>String(a.createdAt||a.ts||'').localeCompare(String(b.createdAt||b.ts||'')));
  return json({success:true,messages,unreadCount})
}
async function portalMessageSend(req,env){
  const b=await req.json().catch(()=>({})),s=await session(b.token,env);
  if(!s)return json({error:'Session expirée.'},401);
  const body=safe(b.body||b.text,5000).trim();
  if(!body)return json({error:'Message requis.'},400);
  const recipient=String(b.recipient||'diane').toLowerCase()==='equipe'?'Équipe NyXia':'Diane Boyer';
  const id=crypto.randomUUID(),createdAt=new Date().toISOString();
  const m={
    id,from:norm(s.email),fromName:s.firstname||'Membre NyXia',to:'__admin__',toName:recipient,
    subject:safe(b.subject||'Message du Cercle',160),body,createdAt,read:false,
    kind:'to_admin',portal:portalSlug(env)
  };
  await env.CASHFLOW_KV.put('message:__admin__:'+createdAt+'_'+id,JSON.stringify(m));
  return json({success:true})
}
async function portalMessageRead(req,env){
  const b=await req.json().catch(()=>({})),s=await session(b.token,env);
  if(!s)return json({error:'Session expirée.'},401);
  const prefix='message:'+norm(s.email)+':',key=String(b.key||'');
  if(!key.startsWith(prefix))return json({error:'Message invalide.'},400);
  const raw=await env.CASHFLOW_KV.get(key);if(!raw)return json({error:'Message introuvable.'},404);
  const m=JSON.parse(raw);m.read=true;await env.CASHFLOW_KV.put(key,JSON.stringify(m));
  return json({success:true})
}

/* ───────────── RÉPERTOIRE DES MÉDIAS MAGIQUES ───────────── */
async function portalMediaKeys(env){
  const get=async k=>String(await env.CASHFLOW_KV.get('nyxia:media-api:'+k)||'').trim();
  return{a:await get('pixabay'),b:await get('pexels'),c:await get('freesound')}
}
const NX_MEDIA_HOSTS=new Set([
  'cdn.pixabay.com','pixabay.com','images.pexels.com','videos.pexels.com',
  'cdn.freesound.org','freesound.org'
]);
function nxProxy(raw,token){
  try{
    const u=new URL(String(raw||''));if(u.protocol!=='https:'||!NX_MEDIA_HOSTS.has(u.hostname))return'';
    return '/api/media/file?u='+encodeURIComponent(u.href)+'&token='+encodeURIComponent(token)
  }catch(_){return''}
}
function nxItem(kind,title,url,thumb,token){
  const p=nxProxy(url,token),t=nxProxy(thumb||url,token);
  if(!p)return null;
  return{kind,title:safe(title||'Ressource NyXia',180),url:p,thumb:t}
}
async function portalMediaImages(req,env){
  const b=await req.json().catch(()=>({})),s=await session(b.token,env);if(!s)return json({error:'Session expirée.'},401);
  const q=String(b.q||'').trim(),filter=String(b.filter||'all');if(!q)return json({error:'Recherche requise.'},400);
  const keys=await portalMediaKeys(env),items=[],jobs=[],notices=[];
  if(keys.a){
    if(filter==='all'||filter==='image')jobs.push((async()=>{try{
      const r=await fetch('https://pixabay.com/api/?key='+encodeURIComponent(keys.a)+'&q='+encodeURIComponent(q)+'&per_page=12&safesearch=true&image_type=photo');
      const d=await r.json();for(const x of d.hits||[]){const it=nxItem('image',x.tags,x.largeImageURL||x.webformatURL,x.previewURL,b.token);if(it)items.push(it)}
    }catch(_){}})());
    if(filter==='all'||filter==='video')jobs.push((async()=>{try{
      const r=await fetch('https://pixabay.com/api/videos/?key='+encodeURIComponent(keys.a)+'&q='+encodeURIComponent(q)+'&per_page=10&safesearch=true');
      const d=await r.json();for(const x of d.hits||[]){const v=x.videos?.medium||x.videos?.small||x.videos?.tiny||{};const it=nxItem('video',x.tags,v.url,x.userImageURL,b.token);if(it)items.push(it)}
    }catch(_){}})());
  }else notices.push('une source visuelle est à configurer');

  if(keys.b){
    if(filter==='all'||filter==='image')jobs.push((async()=>{try{
      const r=await fetch('https://api.pexels.com/v1/search?query='+encodeURIComponent(q)+'&per_page=12',{headers:{Authorization:keys.b}});
      const d=await r.json();for(const x of d.photos||[]){const it=nxItem('image',x.alt||'Image NyXia',x.src?.large||x.src?.original,x.src?.medium,b.token);if(it)items.push(it)}
    }catch(_){}})());
    if(filter==='all'||filter==='video')jobs.push((async()=>{try{
      const r=await fetch('https://api.pexels.com/videos/search?query='+encodeURIComponent(q)+'&per_page=10',{headers:{Authorization:keys.b}});
      const d=await r.json();for(const x of d.videos||[]){const f=(x.video_files||[]).filter(v=>v.link).sort((a,b)=>(a.width||0)-(b.width||0)).pop()||{};const it=nxItem('video','Vidéo NyXia',f.link,x.image,b.token);if(it)items.push(it)}
    }catch(_){}})());
  }else notices.push('une source visuelle est à configurer');

  await Promise.all(jobs);
  return json({success:true,items:items.slice(0,32),notice:notices.length?'Certaines ressources sont momentanément indisponibles.':''})
}
async function portalMediaSounds(req,env){
  const b=await req.json().catch(()=>({})),s=await session(b.token,env);if(!s)return json({error:'Session expirée.'},401);
  const q=String(b.q||'').trim();if(!q)return json({error:'Recherche requise.'},400);
  const keys=await portalMediaKeys(env);if(!keys.c)return json({success:true,items:[],notice:'La banque de sons est momentanément indisponible.'});
  try{
    const r=await fetch('https://freesound.org/apiv2/search/text/?query='+encodeURIComponent(q)+'&page_size=24&fields=id,name,previews,duration',{headers:{Authorization:'Token '+keys.c}});
    const d=await r.json(),items=[];
    for(const x of d.results||[]){const u=x.previews?.['preview-hq-mp3']||x.previews?.['preview-lq-mp3'];const it=nxItem('audio',x.name,u,u,b.token);if(it)items.push(it)}
    return json({success:true,items})
  }catch(_){return json({success:true,items:[],notice:'La banque de sons est momentanément indisponible.'})}
}
async function portalMediaFile(req,env){
  const u=new URL(req.url),s=await session(u.searchParams.get('token'),env);if(!s)return new Response('Unauthorized',{status:401});
  let target;try{target=new URL(u.searchParams.get('u')||'')}catch(_){return new Response('Bad request',{status:400})}
  if(target.protocol!=='https:'||!NX_MEDIA_HOSTS.has(target.hostname))return new Response('Forbidden',{status:403});
  const r=await fetch(target.href,{headers:{'User-Agent':'NyXia-Media/1.0'}});
  if(!r.ok)return new Response('Media unavailable',{status:502});
  const h=new Headers();h.set('Content-Type',r.headers.get('Content-Type')||'application/octet-stream');h.set('Cache-Control','private, max-age=3600');
  return new Response(r.body,{status:200,headers:h})
}

export default{async fetch(request,env){const u=new URL(request.url),p=u.pathname;try{if(p==='/api/login'&&request.method==='POST')return login(request,env);if(p==='/api/check-auth'&&request.method==='POST')return check(request,env);if(p==='/api/logout'&&request.method==='POST')return logout(request,env);if(p==='/api/chat'&&request.method==='POST')return chat(request,env);if(p==='/api/formation/list'&&request.method==='GET')return formationList(request,env);if(p==='/api/tts/nyxia'&&request.method==='POST')return tts(request,env);if(p==='/api/tts/cached-audio'&&request.method==='GET')return cached(request,env);if(p==='/api/messages'&&request.method==='POST')return portalMessageList(request,env);if(p==='/api/messages/send'&&request.method==='POST')return portalMessageSend(request,env);if(p==='/api/messages/read'&&request.method==='POST')return portalMessageRead(request,env);if(p==='/api/media/images'&&request.method==='POST')return portalMediaImages(request,env);if(p==='/api/media/sounds'&&request.method==='POST')return portalMediaSounds(request,env);if(p==='/api/media/file'&&request.method==='GET')return portalMediaFile(request,env)}catch(e){return json({error:'Erreur serveur.',detail:String(e?.message||e)},500)}if(env.ASSETS){if(p==='/'||p==='')return env.ASSETS.fetch(new Request(new URL('/index.html',request.url),request));if(p==='/login')return env.ASSETS.fetch(new Request(new URL('/login.html',request.url),request));if(p==='/dashboard'||p==='/dashbord')return env.ASSETS.fetch(new Request(new URL('/dashbord.html',request.url),request));return env.ASSETS.fetch(request)}return new Response('Not found',{status:404})}};