// NyXia — Coque Portail universelle V2
const PORTAL_CONFIG_B64='__PORTAL_CONFIG_B64__';
const SESSION_TTL=60*60*12;
const DEFAULT_MODEL='deepseek/deepseek-v3.2';
const FALLBACK_MODEL='mistralai/mistral-small-3.2-24b-instruct';
const DG_PERMANENT_KEY='univers:access:permanent';
const DG_GRANT_PREFIX='univers:access:grant:';

function json(d,s=200,h={}){return new Response(JSON.stringify(d),{status:s,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...h}})}
function cfg(){try{const b=Uint8Array.from(atob(PORTAL_CONFIG_B64),c=>c.charCodeAt(0));return JSON.parse(new TextDecoder().decode(b))}catch(_){return{id:'portail',title:'Portail NyXia',shortTitle:'Portail',mission:'',activeAgents:[],agents:[]}}}
const PORTAL=cfg(),AGENTS=Object.fromEntries((PORTAL.agents||[]).map(a=>[String(a.key||'').toLowerCase(),a])),ACTIVE=new Set(PORTAL.activeAgents||[]);
const norm=v=>String(v||'').trim().toLowerCase(),tok=()=>crypto.randomUUID()+crypto.randomUUID();
async function session(env,t){if(!t)return null;const r=await env.CASHFLOW_KV.get('portal:session:'+t);if(!r)return null;try{return JSON.parse(r)}catch(_){return null}}
async function checkAccess(env,email){
 email=norm(email);if(!email)return{allowed:false};
 const per=await env.CASHFLOW_KV.get(DG_PERMANENT_KEY);try{for(const p of JSON.parse(per||'[]'))if(norm(p.email)===email&&(p.allPortals||(p.portalIds||[]).includes(PORTAL.id)))return{allowed:true,type:'permanent'}}catch(_){}
 const c=await env.CASHFLOW_KV.get('client:'+email);try{const u=JSON.parse(c||'{}');if(u.active!==false&&(u.products||[]).map(norm).includes(norm(PORTAL.id)))return{allowed:true,type:'purchased'}}catch(_){}
 const prefix=DG_GRANT_PREFIX+encodeURIComponent(email)+':';let cur;do{const l=await env.CASHFLOW_KV.list({prefix,cursor:cur});for(const k of l.keys||[]){const r=await env.CASHFLOW_KV.get(k.name);try{const g=JSON.parse(r||'{}');if(g.portalId===PORTAL.id&&g.expiresAt&&Date.parse(g.expiresAt)>Date.now())return{allowed:true,type:'temporary',expiresAt:g.expiresAt}}catch(_){}}cur=l.list_complete?null:l.cursor}while(cur);
 return{allowed:false}
}
async function login(req,env){const b=await req.json().catch(()=>({})),email=norm(b.email),password=String(b.password||'');if(!email)return json({error:'Courriel requis.'},400);
 const access=await checkAccess(env,email);if(!access.allowed)return json({error:'Aucun accès actif à ce portail.'},403);
 const cr=await env.CASHFLOW_KV.get('client:'+email);let client={email,firstname:email.split('@')[0]};try{client={...client,...JSON.parse(cr||'{}')}}catch(_){}
 if(client.password&&password!==client.password)return json({error:'Mot de passe incorrect.'},401);
 const t=tok(),s={email,firstname:client.firstname||client.firstName||email.split('@')[0],portal:PORTAL.id,accessType:access.type,expiresAt:access.expiresAt||null};await env.CASHFLOW_KV.put('portal:session:'+t,JSON.stringify(s),{expirationTtl:SESSION_TTL});return json({success:true,token:t,firstname:s.firstname||s.firstName||s.name||'',user:s})
}
async function requireSession(req,env){const u=new URL(req.url);let t=u.searchParams.get('token')||u.searchParams.get('t')||'';if(req.method!=='GET'){try{const c=req.clone();const b=await c.json();t=b.token||t}catch(_){}}return session(env,t)}
async function retrieve(env,agent,q){if(!env.AI||!env.VECTORIZE_INDEX||!q)return'';try{const e=await env.AI.run('@cf/baai/bge-m3',{text:[q]}),r=await env.VECTORIZE_INDEX.query(e.data[0],{topK:6,returnMetadata:'all',namespace:agent});return(r.matches||[]).filter(x=>x.score>.35).map(x=>x.metadata?.texte_original||'').filter(Boolean).join('\n\n---\n\n')}catch(_){return''}}
async function formations(env,agent){const out=[];for(const pre of ['formation:'+PORTAL.id+':'+agent+':','formation:'+agent+':']){let cur;do{const l=await env.CASHFLOW_KV.list({prefix:pre,cursor:cur});for(const k of l.keys||[]){try{const d=JSON.parse(await env.CASHFLOW_KV.get(k.name)||'{}');if(d.id)out.push(d)}catch(_){}}cur=l.list_complete?null:l.cursor}while(cur);if(out.length)break}return out}
function renderBlock(b,first){const t=String(b?.type||'texte').toLowerCase();if(t==='texte'||t==='intervention')return String(b.contenu||'').replace(/\{prenom\}/gi,first||'toi');if(t==='exercice')return['🎯 '+(b.objectif||''),b.consigne||''].filter(Boolean).join('\n\n');if(t==='image')return (b.legende?b.legende+'\n':'')+'[IMAGE: '+b.url+']';if(t==='audio')return (b.intro?b.intro+'\n':'')+'[AUDIO: '+b.url+'|'+(b.titre||'Audio')+']';if(t==='video'||t==='vidéo')return (b.intro?b.intro+'\n':'')+'[VIDEO: '+b.url+'|'+(b.titre||'Vidéo')+']';if(t==='lien')return (b.intro?b.intro+'\n':'')+'[LINK: '+b.url+'|'+(b.titre||'Ouvrir')+']';return''}
async function formationTurn(env,s,agent,msg){const n=norm(msg).normalize('NFD').replace(/[\u0300-\u036f]/g,'');if(!/(formation|cours|suite|continue|reprend)/.test(n))return null;const fs=await formations(env,agent);if(!fs.length)return null;const f=fs[0],mods=f.modules||[];if(!mods.length)return{content:'Cette formation n’a pas encore de module.'};const key='formation-progress:'+PORTAL.id+':'+s.email+':'+agent;let st={mi:0,bi:0};try{st={...st,...JSON.parse(await env.CASHFLOW_KV.get(key)||'{}')}}catch(_){}
 if(/suite|continue|reprend/.test(n)&&st.started)st.bi++;else st.started=true;while(st.mi<mods.length&&st.bi>=(mods[st.mi].blocs||[]).length){st.mi++;st.bi=0}if(st.mi>=mods.length)return{content:'✨ Tu as terminé « '+(f.titre||'la formation')+' ».'};const m=mods[st.mi],b=(m.blocs||[])[st.bi];await env.CASHFLOW_KV.put(key,JSON.stringify(st));return{content:'🎓 **'+(f.titre||'Formation')+' — Module '+(m.numero||st.mi+1)+' · '+(m.titre||'')+'**\n\n'+renderBlock(b,s.firstname)+'\n\n— Quand tu es prête, dis-moi « suite ».'}}
async function openrouter(env,messages,model){const r=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+env.OPENROUTER_API_KEY,'HTTP-Referer':'https://nyxia.top','X-Title':'NyXia Portail'},body:JSON.stringify({model:model||DEFAULT_MODEL,messages,max_tokens:900,temperature:.72})});if(!r.ok)throw Error('OpenRouter '+r.status);const d=await r.json();return d.choices?.[0]?.message?.content?.trim()||''}
async function chat(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const key=norm(b.agent),a=AGENTS[key];if(!a||!ACTIVE.has(key))return json({error:'Personnage indisponible.'},403);
 const ft=await formationTurn(env,s,key,b.message||'');if(ft)return json(ft);
 const brain=await retrieve(env,a.vectorNamespace||key,b.message||'');let imageInfo='';if(b.attachment?.dataUrl)imageInfo='\nLa personne a joint une image nommée '+String(b.attachment.name||'image')+'.';
 const sys=`Tu es ${a.name||key}, personnage de l’univers NyXia dans le portail « ${PORTAL.title} ».
Rôle : ${a.sub||a.visibleRole||''}
Mission : ${a.mission||a.prompt||''}
Personnalité : ${a.personality||''}
Style : ${a.tone||a.languageStyle||''}
Tu réponds en français naturel. Tu restes fidèle à ton identité et à la mission de ce portail.
Tu peux envoyer des ressources uniquement avec ces marqueurs : [IMAGE: https://...], [VIDEO: https://...], [AUDIO: https://...], [PDF: https://...], [LINK: https://...|Texte du bouton].
Quand une image personnalisée doit être créée, invite la personne à utiliser le bouton « Créer une image » du chat; ne fabrique jamais une fausse URL.
${brain?'\nConnaissances pertinentes :\n'+brain:''}${imageInfo}`;
 const messages=[{role:'system',content:sys},...(Array.isArray(b.history)?b.history.slice(-14):[]),{role:'user',content:String(b.message||'')}];
 let content;try{content=await openrouter(env,messages,a.modelPrimary||DEFAULT_MODEL)}catch(_){content=await openrouter(env,messages,a.modelFallback||FALLBACK_MODEL)}return json({content})}
async function imageGenerate(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const p=String(b.prompt||'').trim();if(!p)return json({error:'Décris l’image à créer.'},400);
 const base=(env.NYXIA_IMAGE_BASE_URL||'https://image.pollinations.ai/prompt/').replace(/\/?$/,'/');const q=encodeURIComponent(p+' — esthétique élégante NyXia, haute qualité, sans texte sauf demandé explicitement');const url=base+q+'?width=1024&height=1024&nologo=true&seed='+Math.floor(Math.random()*999999);return json({url,caption:'Voici l’image demandée.'})}
async function tts(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const a=AGENTS[norm(b.agent)]||{},voice=String(a.voiceId||'');if(!voice||!env.ELEVENLABS_API_KEY)return json({error:'Voix non configurée.'},404);const r=await fetch('https://api.elevenlabs.io/v1/text-to-speech/'+encodeURIComponent(voice),{method:'POST',headers:{'xi-api-key':env.ELEVENLABS_API_KEY,'Content-Type':'application/json','Accept':'audio/mpeg'},body:JSON.stringify({text:String(b.text||'').slice(0,4500),model_id:'eleven_multilingual_v2'})});if(!r.ok)return json({error:'Voix indisponible.'},502);return new Response(await r.arrayBuffer(),{headers:{'Content-Type':'audio/mpeg'}})}
async function mediaSearch(req,env){const u=new URL(req.url),s=await session(env,u.searchParams.get('token'));if(!s)return json({error:'Session expirée.'},401);const q=u.searchParams.get('q')||'',out=[];const px=await env.CASHFLOW_KV.get('nyxia:media-api:pexels');if(px&&q){try{const r=await fetch('https://api.pexels.com/v1/search?per_page=18&query='+encodeURIComponent(q),{headers:{Authorization:px}});const d=await r.json();for(const p of d.photos||[])out.push({url:p.src?.large||p.src?.medium})}catch(_){}}return json({results:out})}
async function msgSend(req,env){const b=await req.json().catch(()=>({})),s=await session(env,b.token);if(!s)return json({error:'Session expirée.'},401);const id=crypto.randomUUID(),createdAt=new Date().toISOString(),m={id,from:s.email,fromName:s.firstname||s.email,to:'__admin__',subject:String(b.subject||'Message depuis '+PORTAL.shortTitle),body:String(b.body||''),createdAt,read:false,kind:'to_admin',portal:PORTAL.title};await env.CASHFLOW_KV.put('message:__admin__:'+createdAt+'_'+id,JSON.stringify(m));return json({success:true})}
async function msgInbox(req,env){const u=new URL(req.url),s=await session(env,u.searchParams.get('token'));if(!s)return json({error:'Session expirée.'},401);const out=[];let cur;do{const l=await env.CASHFLOW_KV.list({prefix:'message:'+s.email+':',cursor:cur});for(const k of l.keys||[]){try{out.push(JSON.parse(await env.CASHFLOW_KV.get(k.name)||'{}'))}catch(_){}}cur=l.list_complete?null:l.cursor}while(cur);out.sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||'')));return json({messages:out})}
async function formationList(req,env){const u=new URL(req.url),s=await session(env,u.searchParams.get('token'));if(!s)return json({error:'Session expirée.'},401);const a=norm(u.searchParams.get('agent')),fs=await formations(env,a),key='formation-progress:'+PORTAL.id+':'+s.email+':'+a;return json({formations:fs.map(f=>({id:f.id,titre:f.titre,description:f.description})),hasProgress:!!(await env.CASHFLOW_KV.get(key))})}
function staticReq(req,path){return new Request(new URL(path,req.url),req)}
export default{async fetch(req,env){const u=new URL(req.url),p=u.pathname;try{
 if(p==='/api/login'&&req.method==='POST')return login(req,env);
 if(p==='/api/check-auth'){const b=await req.json().catch(()=>({}));return json({valid:!!(await session(env,b.token))})}
 if(p==='/api/chat'&&req.method==='POST')return chat(req,env);
 if(p==='/api/image/generate'&&req.method==='POST')return imageGenerate(req,env);
 if(p==='/api/tts'&&req.method==='POST')return tts(req,env);
 if(p==='/api/media/search'&&req.method==='GET')return mediaSearch(req,env);
 if(p==='/api/messagerie/send'&&req.method==='POST')return msgSend(req,env);
 if(p==='/api/messagerie/inbox'&&req.method==='GET')return msgInbox(req,env);
 if(p==='/api/formation/list'&&req.method==='GET')return formationList(req,env);
 if(p==='/api/health')return json({ok:true,portal:PORTAL.id,features:['chat','formation','messagerie','media-bank','image-generation','tts','degustation']});
 }catch(e){console.error(e);return json({error:String(e?.message||e)},500)}
 if(env.ASSETS){if(p==='/'||p==='')return env.ASSETS.fetch(staticReq(req,'/index.html'));return env.ASSETS.fetch(req)}return new Response('Not found',{status:404})}}
