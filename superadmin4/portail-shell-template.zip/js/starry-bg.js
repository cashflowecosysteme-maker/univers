
(()=>{const c=document.getElementById('starry-canvas');if(!c)return;const x=c.getContext('2d');let w,h,dpr,stars=[];
function resize(){dpr=Math.min(devicePixelRatio||1,2);w=innerWidth;h=innerHeight;c.width=w*dpr;c.height=h*dpr;c.style.width=w+'px';c.style.height=h+'px';x.setTransform(dpr,0,0,dpr,0,0);stars=Array.from({length:Math.min(180,Math.floor(w*h/9000))},()=>({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.6+.25,a:Math.random()*.75+.15,s:Math.random()*.16+.03}));}
function draw(){x.clearRect(0,0,w,h);for(const s of stars){s.y+=s.s;if(s.y>h+5){s.y=-5;s.x=Math.random()*w}x.globalAlpha=s.a;x.beginPath();x.arc(s.x,s.y,s.r,0,Math.PI*2);x.fillStyle='#fff';x.fill()}x.globalAlpha=1;requestAnimationFrame(draw)}
addEventListener('resize',resize);resize();draw()})()
