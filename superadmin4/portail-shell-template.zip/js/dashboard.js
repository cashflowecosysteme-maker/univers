(()=>{'use strict';
let token=sessionStorage.getItem('nyxia_token')||new URLSearchParams(location.search).get('t')||'';
if(token)sessionStorage.setItem('nyxia_token',token);
const pages=window.NYXIA_PORTAL_PAGES||{};
const q=s=>document.querySelector(s);

function setActive(key){
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.pageKey===key));
  const atelier=q('#portal-atelier');
  const menu=q('#portal-atelier-menu');
  const trigger=q('#portal-atelier-trigger');
  if(atelier&&menu&&trigger){
    const active=!!menu.querySelector('[data-page-key="'+CSS.escape(key)+'"]');
    atelier.classList.toggle('has-active',active);
    if(active){atelier.classList.add('open');trigger.setAttribute('aria-expanded','true')}
  }
}

function openPage(key){
  const url=pages[key]; if(!url)return;
  setActive(key);
  let frame=q('#nyxia-frame');
  if(!frame){
    frame=document.createElement('iframe');
    frame.id='nyxia-frame';
    frame.title='Portail NyXia';
    frame.setAttribute('allow','microphone; autoplay; clipboard-write');
    q('#page-container').replaceChildren(frame);
  }
  frame.src=url+(url.includes('?')?'&':'?')+'t='+encodeURIComponent(token);
  closeMobileMenu();
}

function toggleAtelier(){
  const wrap=q('#portal-atelier'),btn=q('#portal-atelier-trigger');
  if(!wrap||!btn)return;
  const open=!wrap.classList.contains('open');
  wrap.classList.toggle('open',open);
  btn.setAttribute('aria-expanded',open?'true':'false');
}

function closeMobileMenu(){
  q('aside')?.classList.remove('mobile-open');
  q('#mobile-menu-backdrop')?.classList.remove('mobile-open');
}
function toggleMobileMenu(){
  const aside=q('aside'); if(!aside)return;
  const on=!aside.classList.contains('mobile-open');
  aside.classList.toggle('mobile-open',on);
  q('#mobile-menu-backdrop')?.classList.toggle('mobile-open',on);
}

window.openAgentTab=openPage;
window.toggleAtelier=toggleAtelier;

async function init(){
  if(!token){location.href='/login.html';return}
  try{
    const r=await fetch('/api/check-auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})});
    const d=await r.json();
    if(!d.valid){location.href='/login.html';return}
    const n=q('#user-firstname'); if(n)n.textContent=d.firstname||'';
  }catch(_){}

  document.querySelectorAll('[data-page-key]').forEach(el=>el.addEventListener('click',()=>openPage(el.dataset.pageKey)));
  q('#portal-atelier-trigger')?.addEventListener('click',toggleAtelier);
  q('#mobile-menu-btn')?.addEventListener('click',toggleMobileMenu);
  q('#mobile-menu-backdrop')?.addEventListener('click',closeMobileMenu);

  q('#logout-btn')?.addEventListener('click',async()=>{
    try{await fetch('/api/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})})}catch(_){}
    sessionStorage.removeItem('nyxia_token');
    location.href='/login.html';
  });

  openPage(window.NYXIA_DEFAULT_AGENT||Object.keys(pages)[0]||'');
}
document.addEventListener('DOMContentLoaded',init);
})();