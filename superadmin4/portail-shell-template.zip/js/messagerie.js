
(()=>{'use strict';
const $=id=>document.getElementById(id);
const token=sessionStorage.getItem('nyxia_token')||new URLSearchParams(location.search).get('t')||'';
const portal=(new URLSearchParams(location.search).get('portal')||window.NYXIA_PORTAL_ID||'').trim();
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=d=>{try{return new Date(d).toLocaleString('fr-CA',{dateStyle:'medium',timeStyle:'short'})}catch(_){return d||''}};
if($('portalPill'))$('portalPill').textContent=portal||'Portail NyXia';
async function call(path,body){
  const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok||d.success===false)throw Error(d.error||'Erreur de messagerie.');
  return d;
}
function render(messages){
  const box=$('messageList');
  if(!messages.length){box.innerHTML='<div class="empty-state"><div class="empty-icon">✉️</div><strong>Ta messagerie est prête.</strong><span>Écris ton message à Diane Boyer ou à l’équipe NyXia.</span></div>';return}
  const rows=[];
  for(const m of messages){
    if(m.isAdmin)rows.push(`<div class="msg-row team"><div class="bubble"><div class="team-name">${esc(m.fromName||'Diane Boyer')}</div>${esc(m.message||'')}<span class="bubble-meta">${fmt(m.date)}</span></div></div>`);
    else{
      rows.push(`<div class="msg-row me"><div class="bubble">${esc(m.message||'')}<span class="bubble-meta">Toi · ${fmt(m.date)}</span></div></div>`);
      if(m.reply)rows.push(`<div class="msg-row team"><div class="bubble"><div class="team-name">${esc(m.replyFrom||'Diane Boyer')}</div>${esc(m.reply)}<span class="bubble-meta">${fmt(m.replyDate)}</span></div></div>`);
    }
  }
  box.innerHTML=rows.join('');box.scrollTop=box.scrollHeight;
}
async function load(){try{const d=await call('/api/message/list',{token,portal});render((d.messages||[]).sort((a,b)=>new Date(a.date||0)-new Date(b.date||0)))}catch(e){$('messageStatus').textContent=e.message}}
async function send(){
  const text=$('messageText').value.trim();if(!text)return;
  const b=$('sendMessage');b.disabled=true;$('messageStatus').textContent='Envoi…';
  try{await call('/api/message/send',{token,message:text,portal});$('messageText').value='';$('messageStatus').textContent='✓ Message envoyé à Diane Boyer et l’équipe NyXia.';await load()}
  catch(e){$('messageStatus').textContent=e.message}finally{b.disabled=false}
}
$('sendMessage').onclick=send;$('refreshMessages').onclick=load;$('messageText').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
load();
})();
