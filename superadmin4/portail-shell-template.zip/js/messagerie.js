(()=>{'use strict';
const $=id=>document.getElementById(id);
let token=sessionStorage.getItem('nyxia_token')||new URLSearchParams(location.search).get('t')||'';
if(token)try{sessionStorage.setItem('nyxia_token',token)}catch(_){}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(path,body){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Erreur de messagerie.');return d}
function dateFr(v){try{return new Date(v).toLocaleString('fr-CA')}catch(_){return''}}
async function load(){
  if(!token){location.replace('/login.html');return}
  const d=await api('/api/messages',{token});
  const list=$('messageList');const rows=d.messages||[];
  $('unreadText').textContent=(d.unreadCount||0)+' non lu(s) · '+rows.length+' message(s)';
  if(!rows.length){list.innerHTML='<div class="empty">Aucun message pour le moment.</div>';return}
  list.innerHTML=rows.map(m=>{
    const mine=!!m.mine;
    const who=mine?'Moi':esc(m.fromName||'Diane Boyer / Équipe NyXia');
    return '<article class="bubble '+(mine?'mine':'theirs')+'" data-key="'+esc(m.key||'')+'" data-mine="'+(mine?'1':'0')+'">'
      +'<div class="meta">'+who+' · '+esc(dateFr(m.createdAt))+'</div>'
      +(m.subject?'<div class="subject">'+esc(m.subject)+'</div>':'')
      +'<div class="text">'+esc(m.body||m.text||'')+'</div></article>'
  }).join('');
  list.scrollTop=list.scrollHeight;
  for(const el of list.querySelectorAll('.bubble[data-mine="0"][data-key]')){
    const key=el.dataset.key;if(key)api('/api/messages/read',{token,key}).catch(()=>{});
  }
}
async function send(){
  const body=$('body').value.trim();if(!body)return;
  const btn=$('sendBtn');btn.disabled=true;$('sendStatus').className='status';$('sendStatus').textContent='Envoi…';
  try{
    await api('/api/messages/send',{token,recipient:$('recipient').value,subject:$('subject').value.trim(),body});
    $('body').value='';$('subject').value='';$('sendStatus').className='status ok';$('sendStatus').textContent='Message envoyé ✓';await load()
  }catch(e){$('sendStatus').className='status err';$('sendStatus').textContent=e.message}
  finally{btn.disabled=false}
}
$('sendBtn').addEventListener('click',send);$('refreshBtn').addEventListener('click',load);
$('body').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();send()}});
load().catch(e=>{$('messageList').innerHTML='<div class="empty">'+esc(e.message)+'</div>'});
})();