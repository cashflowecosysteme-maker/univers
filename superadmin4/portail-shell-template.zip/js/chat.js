
;(function () {
  try {
    if (window.self !== window.top) {
      document.documentElement.classList.add('nyxia-embedded')
    }
  } catch (_) {
    document.documentElement.classList.add('nyxia-embedded')
  }
})()


var NYXIA_USER = { firstname:'', email:'' }
try {
  var _nyxCtx = JSON.parse(localStorage.getItem('nyxia_user_context') || '{}')
  NYXIA_USER.firstname = String(
    _nyxCtx.firstname ||
    sessionStorage.getItem('nyxia_firstname') ||
    localStorage.getItem('nyxia_username') ||
    ''
  ).trim()
  NYXIA_USER.email = String(_nyxCtx.email || '').trim()
} catch (_) {
  NYXIA_USER.firstname = String(
    sessionStorage.getItem('nyxia_firstname') ||
    localStorage.getItem('nyxia_username') ||
    ''
  ).trim()
}
window.addEventListener('message', function(e) {
  if (!e.data || e.data.type !== 'nyxia_user_context') return
  NYXIA_USER.firstname = String(e.data.firstname || '').trim()
  NYXIA_USER.email = String(e.data.email || '').trim()
  try {
    if (NYXIA_USER.firstname) {
      localStorage.setItem('nyxia_username', NYXIA_USER.firstname)
      sessionStorage.setItem('nyxia_firstname', NYXIA_USER.firstname)
    }
    localStorage.setItem('nyxia_user_context', JSON.stringify(NYXIA_USER))
  } catch (_) {}
})
function nyxiaUserContextText() {
  return NYXIA_USER.firstname
    ? '\n\nPRÉNOM DE LA PERSONNE : ' + NYXIA_USER.firstname + '. Utilise naturellement son prénom dans la conversation lorsque c’est pertinent.'
    : ''
}


  /* ═══════════════════════════════════════════════════════════════════
     PAGE NYXIA AUTONOME — isolée du Dashboard, verrouillée sur l'agent « nyxia ».
  ═══════════════════════════════════════════════════════════════════ */

  var PORTAL_AGENT = __AGENT_JSON__
  var _currentAgent = '__AGENT_KEY__'
  var ALPHA_INFO = {}
  ALPHA_INFO[_currentAgent] = {
    name: __AGENT_NAME_JSON__,
    sub: __AGENT_SUB_JSON__,
    greeting: __AGENT_GREETING_JSON__
  }
  var AGENT_IMAGES = {}; AGENT_IMAGES[_currentAgent] = __AGENT_IMAGE_JSON__
  var AGENT_WELCOME_AUDIO = {}
  var AGENT_WELCOME_VIDEO = {}; AGENT_WELCOME_VIDEO[_currentAgent] = __AGENT_VIDEO_JSON__

  /* ═══════ AUTH ═══════ */
  var sessionToken = sessionStorage.getItem('nyxia_token') || ''
  var clientEmail = '', clientName = localStorage.getItem('nyxia_username') || 'toi'
  ;(function checkAuth() {
    if (!sessionToken) { window.location.href = '/login.html'; return }
    fetch('/api/check-auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ firstname: NYXIA_USER.firstname, token: sessionToken }) })
    .then(function(r){ return r.json() }).then(function(data) {
      if (!data.valid) { window.location.href = '/login.html'; return }
      clientEmail = data.email || ''
      init()
    }).catch(function(){ init() })
  })()

  var chatHistories = {}; chatHistories[_currentAgent] = []
  var CHAT_STORAGE_KEY = 'nyxia_chat_' + _currentAgent

  function loadChatFromStorage() {
    try {
      var raw = sessionStorage.getItem(CHAT_STORAGE_KEY)
      if (!raw) return
      var data = JSON.parse(raw)
      if (!data || !Array.isArray(data.messages)) return
      chatHistories[_currentAgent] = data.messages.slice(-40)
    } catch (e) {}
  }

  function nouveauChat() {
    var name = (ALPHA_INFO[_currentAgent] && ALPHA_INFO[_currentAgent].name) || 'ce personnage'
    if (!confirm('Effacer la conversation avec ' + name + ' ?\n\nTu ne pourras pas la récupérer.')) return
    try { sessionStorage.removeItem(CHAT_STORAGE_KEY) } catch (e) {}
    clearVideoAutoplayed(_currentAgent)
    chatHistories[_currentAgent] = []
    var msgs = document.getElementById('chat-messages-' + _currentAgent)
    if (msgs) msgs.innerHTML = ''
    var sug = document.getElementById('suggestions')
    if (sug) sug.style.display = 'flex'
    var videoUrl = AGENT_WELCOME_VIDEO && AGENT_WELCOME_VIDEO[_currentAgent]
    if (videoUrl) {
      addVideoMessage(videoUrl, _currentAgent, { autoplay: true })
      markVideoAutoplayed(_currentAgent)
    }
    addWelcomeTextMessage(_currentAgent)
  }

  function saveChatToStorage() {
    try {
      sessionStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify({
        messages: (chatHistories[_currentAgent] || []).slice(-40),
        updated: Date.now()
      }))
    } catch (e) {}
  }

  function renderStoredMessages() {
    var list = chatHistories[_currentAgent] || []
    if (!list.length) return
    var msgs = document.getElementById('chat-messages-' + _currentAgent)
    if (!msgs) return
    if (msgs.querySelector('.msg')) return
    var videoUrl = AGENT_WELCOME_VIDEO && AGENT_WELCOME_VIDEO[_currentAgent]
    if (videoUrl) addVideoMessage(videoUrl, _currentAgent, { autoplay: false })
    addWelcomeTextMessage(_currentAgent)
    list.forEach(function(item) {
      if (!item || !item.content) return
      if (item.role === 'user') addUserMessage(item.content)
      else if (item.role === 'assistant') addBotMessage(item.content)
    })
    var sug = document.getElementById('suggestions')
    if (sug && list.length) sug.style.display = 'none'
  }
  var isSpeaking = false, _currentAttachment = null

  function currentHistory() { return chatHistories[_currentAgent] }
  function currentMsgsEl() { return document.getElementById('chat-messages-' + _currentAgent) }

  function avatarHtmlFor(key, sizeClass) {
    sizeClass = sizeClass || 'msg-avatar'
    var src = AGENT_IMAGES[key] || AGENT_IMAGES[_currentAgent]
    var name = (ALPHA_INFO[key] && ALPHA_INFO[key].name) || 'NyXia'
    return '<img src="' + src + '" class="' + sizeClass + '" alt="' + name + '">'
  }
  function updateHeaderAvatar(key) {
    var el = document.getElementById('chat-header-avatar')
    if (!el) return
    el.innerHTML = '<img src="' + (AGENT_IMAGES[key] || AGENT_IMAGES[_currentAgent]) + '" alt="' + ((ALPHA_INFO[key] && ALPHA_INFO[key].name) || 'NyXia') + '">'
  }


  function renderAgentSuggestions() {
    var box = document.getElementById('suggestions')
    if (!box) return
    var list = Array.isArray(PORTAL_AGENT && PORTAL_AGENT.suggestions) ? PORTAL_AGENT.suggestions.filter(Boolean).slice(0, 4) : []
    if (!list.length) {
      list = [
        'Que peux-tu faire pour moi ?',
        'Commencer ma formation',
        'Aide-moi à avancer dans ce portail',
        'Créer une image pour moi'
      ]
    }
    box.innerHTML = ''
    list.forEach(function(item) {
      var text = typeof item === 'string' ? item : String(item && (item.text || item.label || item.title) || '').trim()
      if (!text) return
      var b = document.createElement('button')
      b.type = 'button'
      b.className = 'sug-chip'
      b.textContent = text
      b.addEventListener('click', function() { useSuggestion(b) })
      box.appendChild(b)
    })
    box.style.display = box.children.length ? 'flex' : 'none'
  }

  function init() {
    loadChatFromStorage()
    document.getElementById('chat-header-name').textContent = ALPHA_INFO[_currentAgent].name
    document.getElementById('chat-header-sub').textContent = ALPHA_INFO[_currentAgent].sub
    updateHeaderAvatar('nyxia')
    document.title = ALPHA_INFO[_currentAgent].name + ' — __PORTAL_TITLE__'

    renderAgentSuggestions()
    renderStoredMessages()
    var videoUrl = AGENT_WELCOME_VIDEO.nyxia
    if (videoUrl) {
      var alreadyPlayed = hasVideoAutoplayed('nyxia')
      // Autoplay SEULEMENT la première fois qu'on ouvre ce personnage dans la session
      // Revenir sur NyXia après un autre personnage → vidéo visible, SANS autoplay
      addVideoMessage(videoUrl, 'nyxia', { autoplay: !alreadyPlayed })
      if (!alreadyPlayed) markVideoAutoplayed('nyxia')
    }
    addWelcomeTextMessage('nyxia')

    var chatInput = document.getElementById('chat-input')
    chatInput.addEventListener('input', function() { this.style.height = 'auto'; this.style.height = Math.min(this.scrollHeight, 120) + 'px' })
    chatInput.addEventListener('keydown', function(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } })

    var fi = document.getElementById('chat-file')
    if (fi) fi.addEventListener('change', function() {
      var f = this.files[0]; if (!f) return
      var size = f.size > 1048576 ? (f.size / 1048576).toFixed(1) + 'MB' : Math.round(f.size / 1024) + 'KB'
      _currentAttachment = { name: f.name, type: f.type, data: null }
      var bar = document.getElementById('attach-bar'), nm = document.getElementById('attach-name'), sendBtn = document.getElementById('btn-send')
      if (bar) bar.style.display = 'flex'
      if (nm) nm.innerHTML = '<strong>' + f.name + '</strong> (' + size + ') — ⏳ Chargement...'
      if (sendBtn) sendBtn.disabled = true
      var reader = new FileReader()
      reader.onload = function(e) { _currentAttachment.data = e.target.result.split(',')[1]; if (nm) nm.innerHTML = '<strong>' + f.name + '</strong> (' + size + ') — ✅ Prêt'; if (sendBtn) sendBtn.disabled = false }
      reader.onerror = function() { _currentAttachment = null; if (nm) nm.innerHTML = '❌ Erreur'; if (sendBtn) sendBtn.disabled = false }
      reader.readAsDataURL(f)
    })
    var ca = document.getElementById('btn-clear-attach')
    if (ca) ca.addEventListener('click', function() { _currentAttachment = null; var bar = document.getElementById('attach-bar'), fi2 = document.getElementById('chat-file'); if (bar) bar.style.display = 'none'; if (fi2) fi2.value = '' })
  }


  
  function videoAutoplayKey(agentKey) {
    return 'nyxia_video_autoplayed_' + (agentKey || _currentAgent)
  }
  function hasVideoAutoplayed(agentKey) {
    try { return sessionStorage.getItem(videoAutoplayKey(agentKey)) === '1' } catch (e) { return false }
  }
  function markVideoAutoplayed(agentKey) {
    try { sessionStorage.setItem(videoAutoplayKey(agentKey), '1') } catch (e) {}
  }
  function clearVideoAutoplayed(agentKey) {
    try { sessionStorage.removeItem(videoAutoplayKey(agentKey)) } catch (e) {}
  }

  function welcomeVideoSeenKey(agentKey) {
    return 'nyxia_welcome_video_seen_' + (agentKey || _currentAgent)
  }

  function hasSeenWelcomeVideo(agentKey) {
    try { return localStorage.getItem(welcomeVideoSeenKey(agentKey)) === '1' } catch (e) { return false }
  }

  function markWelcomeVideoSeen(agentKey) {
    try { localStorage.setItem(welcomeVideoSeenKey(agentKey), '1') } catch (e) {}
  }

  function rejouerVideoAccueil() {
    var videoUrl = AGENT_WELCOME_VIDEO && AGENT_WELCOME_VIDEO[_currentAgent]
    if (!videoUrl) return
    var msgs = document.getElementById('chat-messages-' + _currentAgent)
    if (msgs) {
      var old = msgs.querySelector('video[data-welcome="1"]')
      if (old) {
        var msg = old.closest('.msg')
        if (msg) msg.remove()
      }
    }
    addVideoMessage(videoUrl, _currentAgent, { autoplay: false })
  }

  function addVideoMessage(videoUrl, agentKey, opts) {
    opts = opts || {}
    // autoplay UNIQUEMENT si opts.autoplay === true (première visite)
    var autoplay = opts.autoplay === true

    var msgs = document.getElementById('chat-messages-' + agentKey)
    if (!msgs) return
    // Évite les doublons vidéo déjà présents
    if (msgs.querySelector('video[data-welcome="1"]')) return

    var div = document.createElement('div'); div.className = 'msg bot'
    div.style.cssText = 'display:flex;gap:10px;align-items:flex-start'
    var wrapper = document.createElement('div'); wrapper.style.cssText = 'display:flex;flex-direction:column;gap:4px;max-width:100%;flex:1'
    var videoWrap = document.createElement('div')
    videoWrap.style.cssText = 'border-radius:14px;overflow:hidden;max-width:320px;background:#000'
    var video = document.createElement('video')
    video.src = videoUrl
    video.controls = true
    video.playsInline = true
    video.setAttribute('data-welcome', '1')
    video.style.cssText = 'width:100%;display:block'
    videoWrap.appendChild(video)
    wrapper.appendChild(videoWrap)
    div.innerHTML = avatarHtmlFor(agentKey)
    div.appendChild(wrapper)
    msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight

    if (autoplay) {
      markWelcomeVideoSeen(agentKey)
      video.play().catch(function() {
        var go = function() {
          video.play().catch(function(){})
          document.removeEventListener('click', go)
          document.removeEventListener('keydown', go)
          document.removeEventListener('touchstart', go)
        }
        document.addEventListener('click', go)
        document.addEventListener('keydown', go)
        document.addEventListener('touchstart', go)
      })
    }
  }

  function addWelcomeTextMessage(agentKey) {
    var msgs = document.getElementById('chat-messages-' + agentKey)
    if (!msgs || msgs.querySelector('[data-welcome-text="1"]')) return
    var greeting = ALPHA_INFO[agentKey] && ALPHA_INFO[agentKey].greeting
    if (!greeting) return

    var div = document.createElement('div'); div.className = 'msg bot'
    div.setAttribute('data-welcome-text', '1')
    div.style.cssText = 'display:flex;gap:10px;align-items:flex-start'
    var wrapper = document.createElement('div'); wrapper.style.cssText = 'display:flex;flex-direction:column;gap:4px;max-width:100%;flex:1'
    var bubble = document.createElement('div'); bubble.className = 'msg-bubble'
    bubble.innerHTML = cleanMarkdown(escHtml(greeting)).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')
    wrapper.appendChild(bubble)
    div.innerHTML = avatarHtmlFor(agentKey)
    div.appendChild(wrapper)
    msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight
  }



  function normalizeForCompare(s) {
    return String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  }

  function detectImagePrompt(text) {
    var raw = String(text || '').trim()
    if (!raw) return ''
    var norm = normalizeForCompare(raw)
    var patterns = [
      /^\/image\s*[:\-]?\s*(.+)$/i,
      /^(?:cree|creer|crée|créer|genere|generer|génère|générer|dessine|fabrique|fais(?:-moi)?|fais moi)\s+(?:moi\s+)?(?:une?\s+)?image\s*[:\-]?\s*(.+)$/i,
      /^(?:une?\s+)?image\s*[:\-]\s*(.+)$/i
    ]
    for (var i = 0; i < patterns.length; i++) {
      var m = raw.match(patterns[i])
      if (m && m[1] && m[1].trim()) return m[1].trim()
    }
    if (/\b(image|visuel|illustration|portrait|affiche|couverture)\b/i.test(norm) && /\b(cree|creer|crée|créer|genere|generer|génère|générer|dessine|fabrique|fais)\b/i.test(norm)) {
      return raw.replace(/^(.*?)(?:image\s*[:\-]?)/i, '').trim() || raw
    }
    return ''
  }

  function triggerImageMode() {
    var input = document.getElementById('chat-input')
    var base = input && input.value ? String(input.value).trim() : ''
    var desc = detectImagePrompt(base) || base
    if (!desc) {
      desc = window.prompt("Décris l'image à créer :", '') || ''
    }
    desc = String(desc || '').trim()
    if (!desc) return
    if (input) { input.value = ''; input.style.height = 'auto' }
    sendMessageText('Créer une image : ' + desc, false, { forceImage: true, imagePrompt: desc })
  }

  function appendDirectImage(wrapper, imageUrl, altText) {
    var safe = safeExternalUrl(imageUrl)
    if (!safe) return
    var imgWrap = document.createElement('div'); imgWrap.className = 'msg-img-wrap'
    var img = document.createElement('img'); img.src = safe; img.alt = altText || 'Image générée'; img.loading = 'lazy'
    img.onload = function() {
      requestAnimationFrame(function() { img.classList.add('loaded') })
      var msgs = currentMsgsEl(); if (msgs) msgs.scrollTop = msgs.scrollHeight
    }
    imgWrap.appendChild(img)
    wrapper.appendChild(imgWrap)
  }

  function requestImageGeneration(promptText, requestAgent, btn) {
    fetch('/api/image', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: promptText, agent: requestAgent, token: sessionToken })
    })
    .then(function(r){ return r.json().then(function(data){ return { ok: r.ok, data: data } }) })
    .then(function(res) {
      removeTyping()
      if (!res.ok) throw new Error((res.data && res.data.error) || "Impossible de créer l'image pour le moment.")
      var reply = ((res.data && res.data.caption) || "Voici l'image que j'ai créée pour toi.") + '\n\n[IMAGE_URL: ' + (res.data.url || '') + '|' + promptText.replace(/\]/g, '') + ']'
      addBotMessage(reply)
      chatHistories[requestAgent].push({ role: 'assistant', content: reply })
      saveChatToStorage()
      if (chatHistories[requestAgent].length > 20) chatHistories[requestAgent] = chatHistories[requestAgent].slice(-20)
      btn.disabled = false
    })
    .catch(function(err){
      removeTyping()
      addBotMessage((err && err.message) ? err.message : 'Petite interruption... réessaie dans un instant 💜')
      btn.disabled = false
    })
  }

  function useSuggestion(btn) {
    var _au = btn.getAttribute('data-audio')
    var _vi = btn.getAttribute('data-video')
    var _im = btn.getAttribute('data-image')
    var _intro = btn.getAttribute('data-intro') || ''
    if (_au || _vi || _im) {
      var _body = _intro
      if (_vi) _body += (_body ? '\n\n' : '') + '[VIDEO: ' + _vi.trim() + ']'
      if (_au) _body += (_body ? '\n\n' : '') + '[AUDIO: ' + _au.trim() + ']'
      if (_im) _body += (_body ? '\n\n' : '') + '[PHOTO: ' + _im.trim() + ']'
      addBotMessage(_body)
      return
    }
    var text = (btn.textContent || '').trim()
    if (!text) return
    if (/cr[ée]er? une image|g[ée]n[ée]rer? une image/i.test(text)) { triggerImageMode(); return }
    var input = document.getElementById('chat-input')
    if (input) { input.value = text; input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px' }
    var sug = document.getElementById('suggestions')
    if (sug) sug.style.display = 'none'
    sendMessage()
  }

  function sendMessage() {
    var input = document.getElementById('chat-input')
    var text = input.value.trim()
    if (!text && !_currentAttachment) return
    input.value = ''; input.style.height = 'auto'
    var sug = document.getElementById('suggestions')
    if (sug) sug.style.display = 'none'
    sendMessageText(text || '📎 Fichier joint', false, {})
  }

  function sendMessageText(text, fromVoice, options) {
    _inputWasVoice = !!fromVoice
    var attachmentToSend = _currentAttachment ? JSON.parse(JSON.stringify(_currentAttachment)) : null
    var displayText = text
    if (attachmentToSend) { displayText = text ? text + '\n📎 ' + attachmentToSend.name : '📎 ' + attachmentToSend.name }
    addUserMessage(displayText)
    var historyContent = text
    if (attachmentToSend) { historyContent = (text ? text + '\n' : '') + '[Fichier joint: ' + attachmentToSend.name + ' (' + attachmentToSend.type + ')]' }
    currentHistory().push({ role: 'user', content: historyContent })
    saveChatToStorage()
    if (_currentAttachment) {
      _currentAttachment = null
      var bar = document.getElementById('attach-bar'), fi = document.getElementById('chat-file')
      if (bar) bar.style.display = 'none'; if (fi) fi.value = ''
    }
    var btn = document.getElementById('btn-send')
    var requestAgent = _currentAgent
    var opts = options || {}
    var requestedImagePrompt = ''
    if (!attachmentToSend) requestedImagePrompt = String(opts.imagePrompt || (opts.forceImage ? String(text || '').replace(/^Créer une image\s*:\s*/i, '').trim() : detectImagePrompt(text)) || '').trim()
    btn.disabled = true
    addTyping()
    if (requestedImagePrompt) {
      requestImageGeneration(requestedImagePrompt, requestAgent, btn)
      return
    }
    fetch('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, history: chatHistories[requestAgent].slice(-10), userName: clientName, agent: requestAgent, attachment: attachmentToSend, token: sessionToken })
    })
    .then(function(r){ return r.json() })
    .then(function(data) {
      removeTyping()
      var reply = data.content || 'Erreur inattendue — réessaie dans un instant 💜'
      addBotMessage(reply)
      chatHistories[requestAgent].push({ role: 'assistant', content: reply })
      saveChatToStorage()
      if (chatHistories[requestAgent].length > 20) chatHistories[requestAgent] = chatHistories[requestAgent].slice(-20)
      if (_inputWasVoice) {
        var msgsEl = document.getElementById('chat-messages-' + requestAgent)
        var lastBotMsg = msgsEl ? msgsEl.querySelector('.msg.bot:last-child') : null
        if (lastBotMsg) {
          var speakBtn = Array.prototype.find.call(lastBotMsg.querySelectorAll('button'), function(b) { return b.textContent.indexOf('Écouter') !== -1 })
          if (speakBtn) speakBtn.click()
        }
      }
      _inputWasVoice = false
      btn.disabled = false
    })
    .catch(function(){ removeTyping(); addBotMessage('Petite interruption... réessaie dans un instant 💜'); btn.disabled = false })
  }

  function safeLivingVideoUrl(rawUrl) {
    try {
      var parsed = new URL(String(rawUrl || '').trim(), window.location.href)
      return parsed.protocol === 'https:' ? parsed.href : ''
    } catch (e) { return '' }
  }

  function livingVideoEmbedUrl(rawUrl) {
    try {
      var parsed = new URL(rawUrl)
      var host = parsed.hostname.toLowerCase().replace(/^www\./, '')
      var videoId = ''

      if (host === 'youtu.be') videoId = parsed.pathname.split('/').filter(Boolean)[0] || ''
      if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
        videoId = parsed.searchParams.get('v') || ''
        if (!videoId) {
          var youtubeParts = parsed.pathname.split('/').filter(Boolean)
          if (youtubeParts[0] === 'embed' || youtubeParts[0] === 'shorts') videoId = youtubeParts[1] || ''
        }
      }
      if (/^[A-Za-z0-9_-]{6,}$/.test(videoId)) {
        return 'https://www.youtube-nocookie.com/embed/' + videoId
      }

      if (host === 'vimeo.com' || host === 'player.vimeo.com') {
        var vimeoMatch = parsed.pathname.match(/(?:video\/)?(\d+)/)
        if (vimeoMatch) return 'https://player.vimeo.com/video/' + vimeoMatch[1]
      }

      if (host === 'iframe.videodelivery.net') return parsed.href
      if (host === 'watch.cloudflarestream.com') {
        var streamId = parsed.pathname.split('/').filter(Boolean)[0] || ''
        if (/^[A-Za-z0-9_-]+$/.test(streamId)) return 'https://iframe.videodelivery.net/' + streamId
      }
      if (host === 'drive.google.com') {
        var driveMatch = parsed.pathname.match(/\/file\/d\/([A-Za-z0-9_-]+)/)
        var driveId2 = driveMatch ? driveMatch[1] : (parsed.searchParams.get('id') || '')
        if (driveId2) return 'https://drive.google.com/file/d/' + driveId2 + '/preview'
      }
    } catch (e) {}
    return ''
  }

  function appendLivingVideo(wrapper, videoUrl) {
    var card = document.createElement('div')
    card.style.cssText = 'width:min(100%,560px);margin-top:6px;padding:10px;border-radius:16px;border:1px solid rgba(123,92,255,0.22);background:linear-gradient(145deg,rgba(123,92,255,0.09),rgba(255,255,255,0.025));box-shadow:0 12px 30px rgba(20,12,48,0.16)'

    var label = document.createElement('div')
    label.textContent = '🎬 Formation vivante'
    label.style.cssText = 'font-size:12px;font-weight:700;color:#c4b5fd;letter-spacing:.02em;margin:1px 2px 9px'
    card.appendChild(label)

    var frame = document.createElement('div')
    frame.style.cssText = 'position:relative;width:100%;aspect-ratio:16/9;overflow:hidden;border-radius:11px;background:#070713'
    var embedUrl = livingVideoEmbedUrl(videoUrl)

    if (embedUrl) {
      var iframe = document.createElement('iframe')
      iframe.src = embedUrl
      iframe.title = 'Vidéo de formation'
      iframe.loading = 'lazy'
      iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share'
      iframe.allowFullscreen = true
      iframe.referrerPolicy = 'strict-origin-when-cross-origin'
      iframe.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:0'
      frame.appendChild(iframe)
    } else {
      var video = document.createElement('video')
      video.src = videoUrl
      video.controls = true
      video.playsInline = true
      video.preload = 'metadata'
      video.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#070713'
      frame.appendChild(video)
    }

    card.appendChild(frame)
    wrapper.appendChild(card)
  }

  function foDriveId(u){ try{ var p=new URL(u); if(p.hostname.replace(/^www\./,'')!=='drive.google.com') return ''; var m=p.pathname.match(/\/file\/d\/([A-Za-z0-9_-]+)/); return m?m[1]:(p.searchParams.get('id')||''); }catch(e){ return ''; } }

  function appendAudio(wrapper, url) {
    var gid = foDriveId(url)
    var card = document.createElement('div'); card.style.cssText = 'width:min(100%,520px);margin-top:6px'
    if (gid) {
      var ifr = document.createElement('iframe'); ifr.src = 'https://drive.google.com/file/d/' + gid + '/preview'; ifr.allow = 'autoplay'
      ifr.style.cssText = 'width:100%;height:120px;border:0;border-radius:12px;background:#0f1c3f'; card.appendChild(ifr)
    } else {
      var au = document.createElement('audio'); au.src = url; au.controls = true; au.preload = 'metadata'
      au.style.cssText = 'width:100%;display:block'; card.appendChild(au)
    }
    wrapper.appendChild(card)
  }

  function appendPhoto(wrapper, url) {
    var img = document.createElement('img'); img.src = url; img.alt = 'Image'
    img.style.cssText = 'width:min(100%,520px);border-radius:12px;display:block;margin-top:6px'
    img.onerror = function(){ img.style.display = 'none' }
    wrapper.appendChild(img)
  }


  function safeExternalUrl(raw) {
    var value = String(raw || '').trim()
    if (!value) return ''
    if (/^data:image\//i.test(value)) return value
    try {
      var u = new URL(value, window.location.href)
      return (u.protocol === 'https:' || u.protocol === 'http:') ? u.href : ''
    } catch (_) { return '' }
  }

  function extractResourceLinks(text) {
    var links = []
    var cleaned = String(text || '')

    function resourceKind(url, explicitKind) {
      if (String(explicitKind || '').toUpperCase() === 'PDF') return 'pdf'
      var u = String(url || '').split(/[?#]/)[0].toLowerCase()
      if (/\.(mp3|m4a|wav|ogg|aac|flac)$/.test(u)) return 'audio'
      if (/\.pdf$/.test(u)) return 'pdf'
      return 'link'
    }

    cleaned = cleaned.replace(/\[(LINK|PDF)\s*:\s*([^\]|]+)(?:\|([^\]]+))?\]/gi, function(_, kind, url, label) {
      var safe = safeExternalUrl(url)
      if (safe) {
        var rk = resourceKind(safe, kind)
        var nice = String(label || '').trim()
        if (!nice) nice = rk === 'pdf' ? 'Ouvrir le PDF' : (rk === 'audio' ? 'Écouter l’audio' : 'Ouvrir')
        links.push({ url: safe, label: nice, kind: rk })
      }
      return ''
    })

    cleaned = cleaned.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/gi, function(_, label, url) {
      var safe = safeExternalUrl(url)
      if (safe) {
        var rk = resourceKind(safe, '')
        links.push({ url: safe, label: String(label || (rk === 'audio' ? 'Écouter l’audio' : 'Ouvrir')).trim() || 'Ouvrir', kind: rk })
      }
      return ''
    })

    cleaned = cleaned.replace(/\b(https?:\/\/[^\s<]+\.(?:mp3|m4a|wav|ogg|aac|flac)(?:[?#][^\s<]*)?)\b/gi, function(_, url) {
      var safe = safeExternalUrl(url)
      if (safe) links.push({ url: safe, label: 'Écouter l’audio', kind: 'audio' })
      return ''
    })

    cleaned = cleaned.replace(/\b(https?:\/\/[^\s<]+\.pdf(?:[?#][^\s<]*)?)\b/gi, function(_, url) {
      var safe = safeExternalUrl(url)
      if (safe) links.push({ url: safe, label: 'Ouvrir le PDF', kind: 'pdf' })
      return ''
    })

    return { text: cleaned.trim(), links: links }
  }

  function appendGlassLink(wrapper, item) {
    if (!item || !item.url) return
    var a = document.createElement('a')
    a.href = item.url
    a.target = '_blank'
    a.rel = 'noopener noreferrer'
    a.className = 'nx-glass-link'
    a.innerHTML = '<span class="nx-glass-link-icon">✦</span><span>' + escHtml(item.label || 'Ouvrir la ressource') + '</span><span class="nx-glass-link-arrow">↗</span>'
    wrapper.appendChild(a)
  }

  function addBotMessage(text) {
    var parsedLinks = extractResourceLinks(text)
    text = parsedLinks.text
    var msgAgent = _currentAgent
    var msgs = document.getElementById('chat-messages-' + msgAgent)
    var div = document.createElement('div'); div.className = 'msg bot'
    div.style.cssText = 'display:flex;gap:10px;align-items:flex-start'
    var wrapper = document.createElement('div'); wrapper.style.cssText = 'display:flex;flex-direction:column;gap:4px;max-width:100%;flex:1'

    var imageUrlRegex = /\[IMAGE_URL\s*:\s*([^\]|]+)(?:\|([^\]]+))?\]/i
    var imageUrlMatch = text.match(imageUrlRegex)
    var imgRegex = /\[IMAGE\s*:\s*([\s\S]*?)\]/i
    var imgMatch = text.match(imgRegex)
    var parchRegex = /\[(?:PROMPT|PARCHEMIN)\]([\s\S]*?)\[\/(?:PROMPT|PARCHEMIN)\]/i
    var parchMatch = text.match(parchRegex)
    var parchImgRegex = /\[(?:PROMPT|PARCHEMIN)_IMAGE\s*:\s*([\s\S]*?)\]/i
    var parchImgMatch = text.match(parchImgRegex)
    var videoRegex = /\[VIDEO\s*:\s*([^\]|\r\n]+)(?:\|([^\]\r\n]+))?\]/i
    var videoMatch = text.match(videoRegex)
    var audioRegex = /\[AUDIO\s*:\s*([^\]|\r\n]+)(?:\|([^\]\r\n]+))?\]/i
    var audioMatch = text.match(audioRegex)
    var photoRegex = /\[PHOTO\s*:\s*([^\]\r\n]+)\]/i
    var photoMatch = text.match(photoRegex)
    var textWithoutImg = text.replace(imageUrlRegex, '').replace(imgRegex, '').replace(parchRegex, '').replace(parchImgRegex, '').replace(videoRegex, '').replace(audioRegex, '').replace(photoRegex, '').trim()
    var imageUrl = imageUrlMatch ? safeExternalUrl(imageUrlMatch[1]) : ''
    var imageAlt = imageUrlMatch && imageUrlMatch[2] ? imageUrlMatch[2].trim() : ''
    var imgDesc = imgMatch ? imgMatch[1].trim() : null
    var parchContent = parchMatch ? parchMatch[1].trim() : null
    var parchImgUrl = parchImgMatch ? parchImgMatch[1].trim() : null
    var videoUrl = videoMatch ? safeLivingVideoUrl(videoMatch[1]) : ''

    var bubble = document.createElement('div'); bubble.className = 'msg-bubble'
    if (textWithoutImg) {
      bubble.innerHTML = cleanMarkdown(escHtml(textWithoutImg)).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')
    } else if (!imageUrl && !imgDesc && !parchContent && !videoMatch && !audioMatch && !photoMatch) {
      bubble.innerHTML = cleanMarkdown(escHtml(text)).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')
    } else {
      bubble.style.display = 'none'
    }
    wrapper.appendChild(bubble)

    if (imageUrl) appendDirectImage(wrapper, imageUrl, imageAlt || textWithoutImg || 'Image générée')
    if (videoUrl) appendLivingVideo(wrapper, videoUrl)
    if (audioMatch) { var _auU = safeLivingVideoUrl(audioMatch[1]); if (_auU) appendAudio(wrapper, _auU) }
    if (photoMatch) { var _phU = safeLivingVideoUrl(photoMatch[1]); if (_phU) appendPhoto(wrapper, _phU) }

    if (parchContent) {
      var parchWrap = document.createElement('div')
      parchWrap.style.cssText = 'background:rgba(123,92,255,0.06);border:1px solid rgba(123,92,255,0.18);border-radius:14px;padding:16px;margin-top:4px;max-width:460px'

      if (parchImgUrl) {
        var parchImgEl = document.createElement('img')
        parchImgEl.src = parchImgUrl
        parchImgEl.alt = 'Image du prompt'
        parchImgEl.style.cssText = 'width:100%;border-radius:10px;display:block;margin-bottom:12px;max-height:320px;object-fit:cover'
        parchImgEl.onerror = function() { parchImgEl.style.display = 'none' }
        parchWrap.appendChild(parchImgEl)
      }

      var parchText = document.createElement('div')
      parchText.style.cssText = 'font-size:13.5px;line-height:1.7;white-space:pre-wrap;color:var(--t2)'
      parchText.textContent = parchContent
      parchWrap.appendChild(parchText)

      var parchBtnRow = document.createElement('div')
      parchBtnRow.style.cssText = 'display:flex;gap:8px;margin-top:12px'

      var copyBtn = document.createElement('button')
      copyBtn.textContent = '📋 Copier le prompt'
      copyBtn.style.cssText = 'flex:1;padding:9px;border-radius:9px;border:1px solid rgba(123,92,255,0.3);background:rgba(123,92,255,0.1);color:var(--t2);font-family:Outfit,sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:all .15s'
      copyBtn.addEventListener('click', function() {
        navigator.clipboard.writeText(parchContent).then(function() {
          copyBtn.textContent = '✅ Copié !'
          setTimeout(function() { copyBtn.textContent = '📋 Copier le prompt' }, 2500)
        }).catch(function() { copyBtn.textContent = '⚠️ Sélectionne le texte manuellement' })
      })
      parchBtnRow.appendChild(copyBtn)

      if (parchImgUrl) {
        var dlBtn = document.createElement('a')
        dlBtn.textContent = '⬇ Télécharger l\'image'
        dlBtn.href = parchImgUrl
        dlBtn.target = '_blank'
        dlBtn.rel = 'noopener'
        dlBtn.download = 'prompt.jpg'
        dlBtn.style.cssText = 'flex:1;padding:9px;border-radius:9px;border:1px solid rgba(123,92,255,0.3);background:rgba(123,92,255,0.1);color:var(--t2);font-family:Outfit,sans-serif;font-size:13px;font-weight:600;cursor:pointer;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center'
        parchBtnRow.appendChild(dlBtn)
      }

      parchWrap.appendChild(parchBtnRow)
      wrapper.appendChild(parchWrap)
    }

    if (imgDesc) {
      var imgWrap = document.createElement('div'); imgWrap.className = 'msg-img-wrap'
      var loader = document.createElement('div'); loader.className = 'msg-img-loader'
      loader.innerHTML = '<div class="msg-img-spinner"></div>🎨 Génération en cours...'
      imgWrap.appendChild(loader); wrapper.appendChild(imgWrap)

      var cleanDesc = imgDesc.replace(/\n/g, ' ').substring(0, 300).trim()
      var seed = Math.floor(Math.random() * 999999)
      var primaryUrl = 'https://image.pollinations.ai/prompt/' + encodeURIComponent(cleanDesc + ', high quality, detailed, coherent composition') + '?width=768&height=768&model=flux&seed=' + seed + '&private=true'

      var img = document.createElement('img'); img.alt = cleanDesc; img.crossOrigin = 'anonymous'
      var hasRetried = false

      img.onload = function() {
        loader.remove()
        imgWrap.style.background = 'none'; imgWrap.style.border = 'none'
        imgWrap.appendChild(img)
        requestAnimationFrame(function() { img.classList.add('loaded') })
        msgs.scrollTop = msgs.scrollHeight
      }

      img.onerror = function() {
        if (!hasRetried) {
          hasRetried = true
          var fallbackUrl = 'https://image.pollinations.ai/prompt/' + encodeURIComponent(cleanDesc.substring(0, 100)) + '?width=768&height=768&seed=' + seed + '&private=true'
          img.src = fallbackUrl
        } else {
          loader.innerHTML = '⚠️ Erreur de génération — réessaie'
        }
      }
      img.src = primaryUrl
    }

    var bs = 'padding:2px 9px;border-radius:50px;border:1px solid rgba(123,92,255,0.15);background:rgba(123,92,255,0.04);color:var(--t4);font-family:Outfit,sans-serif;font-size:11px;cursor:pointer;transition:all .15s'
    parsedLinks.links.forEach(function(item) {
      if (item.kind === 'audio') appendAudio(wrapper, item.url)
      else appendGlassLink(wrapper, item)
    })

    var acts = document.createElement('div'); acts.style.cssText = 'display:flex;gap:4px;flex-wrap:wrap;margin-top:2px'
    var textForSpeak = textWithoutImg || (videoUrl ? '' : text)
    var exportText = textWithoutImg || (videoUrl ? 'Formation vidéo' : text)
    if (videoUrl) exportText += '\n\nVidéo : ' + videoUrl
    var agentName = (ALPHA_INFO[msgAgent] && ALPHA_INFO[msgAgent].name) || 'NyXia'

    var spk = document.createElement('button'); spk.style.cssText = bs; spk.textContent = '🔊 Écouter'
    spk.addEventListener('click', function() { speakMsg(spk, textForSpeak) }); acts.appendChild(spk)

    var cpy = document.createElement('button'); cpy.style.cssText = bs; cpy.textContent = '📋 Copier'
    cpy.addEventListener('click', function() { navigator.clipboard.writeText(exportText).then(function() { cpy.textContent = '✓'; setTimeout(function() { cpy.textContent = '📋 Copier' }, 2000) }) }); acts.appendChild(cpy)

    var ret = document.createElement('button'); ret.style.cssText = bs; ret.textContent = '↺ Réessayer'
    ret.addEventListener('click', function() {
      var hist = chatHistories[msgAgent]
      var last = hist.filter(function(m) { return m.role === 'user' }).pop()
      if (last) {
        if (hist[hist.length - 1].role === 'assistant') hist.pop()
        div.remove()
        sendMessageText(last.content, false)
      }
    }); acts.appendChild(ret)

    var pdfBtn = document.createElement('button'); pdfBtn.style.cssText = bs; pdfBtn.textContent = '⬇ PDF'
    pdfBtn.addEventListener('click', function() {
      var w = window.open('', '_blank'); if (!w) return
      var body = '<h2 style="color:#7B5CFF">' + agentName + ' — NyXia</h2>' + escHtml(exportText).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>')
      w.document.write('<!DOCTYPE html><html><head><title>' + agentName + ' — NyXia</title></head><body>' + body + '</body></html>')
      w.document.close(); setTimeout(function() { w.print() }, 300)
    }); acts.appendChild(pdfBtn)

    wrapper.appendChild(acts)
    div.innerHTML = avatarHtmlFor(msgAgent)
    div.appendChild(wrapper)
    msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight
  }

  function addUserMessage(text) {
    var msgs = currentMsgsEl()
    var div = document.createElement('div'); div.className = 'msg user'
    var initial = (clientName || 'T').charAt(0).toUpperCase()
    div.innerHTML = '<div class="msg-bubble">' + escHtml(text) + '</div><div class="msg-avatar" style="background:linear-gradient(135deg,#7B5CFF,#5A6CFF);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;font-size:13px;border-radius:50%;width:32px;height:32px;flex-shrink:0">' + initial + '</div>'
    msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight
  }

  function addTyping() {
    var msgs = currentMsgsEl()
    var div = document.createElement('div'); div.className = 'msg bot'; div.id = 'typing-indicator'
    div.style.cssText = 'display:flex;gap:10px;align-items:flex-start'
    div.innerHTML = avatarHtmlFor(_currentAgent) + '<div class="msg-bubble"><span class="nx-dots"><i></i><i></i><i></i></span></div>'
    msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight
  }

  function removeTyping() { var t = document.getElementById('typing-indicator'); if (t) t.remove() }

  function stopSpeakBtn(btn) {
    btn._nxSpeaking = false; btn.textContent = '🔊 Écouter'; btn.style.borderColor = 'rgba(123,92,255,0.15)'; btn.style.color = 'var(--t4)'; btn.style.background = 'rgba(123,92,255,0.04)'
    if (btn._nxAudio) { btn._nxAudio.pause(); btn._nxAudio = null } if (btn._nxAudioUrl) { try { URL.revokeObjectURL(btn._nxAudioUrl) } catch (_) {} btn._nxAudioUrl = null }
  }

  function speakMsg(btn, text) {
    if (btn._nxSpeaking) { window.speechSynthesis && window.speechSynthesis.cancel(); stopSpeakBtn(btn); return }
    window.speechSynthesis && window.speechSynthesis.cancel()
    document.querySelectorAll('.msg button').forEach(function(b) { if (b._nxSpeaking) stopSpeakBtn(b) })
    speakViaServer(btn, text, _currentAgent)
  }

  function speakViaServer(btn, text, agentKey) {
    var clean = cleanForSpeech(text)
    if (!clean) return
    btn._nxSpeaking = true
    btn.textContent = '⏳ Un instant...'
    btn.style.borderColor = 'rgba(0,230,118,0.4)'
    btn.style.color = '#00E676'
    btn.style.background = 'rgba(0,230,118,0.08)'

    fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: sessionToken, text: clean, agent: agentKey })
    })
    .then(async function(r) {
      if (!r.ok) {
        var data = await r.json().catch(function(){ return {} })
        throw new Error(data.error || ('Voix indisponible (' + r.status + ')'))
      }
      return r.blob()
    })
    .then(function(blob) {
      var url = URL.createObjectURL(blob)
      var audio = new Audio(url)
      btn._nxAudio = audio
      btn._nxAudioUrl = url
      btn.textContent = '⏹ Arrêter'
      audio.play().catch(function(err){ throw err })
      audio.onended = audio.onerror = function() {
        try { URL.revokeObjectURL(url) } catch (_) {}
        stopSpeakBtn(btn)
      }
    })
    .catch(function(err) {
      console.error('🔊 Voix (' + agentKey + ') : ' + err.message)
      btn.title = err.message
      btn.textContent = '⚠️ Voix indisponible'
      setTimeout(function(){ stopSpeakBtn(btn) }, 2500)
    })
  }

  var _msgAccueil = null
  function jouerMessageAccueil() {
    var btn = document.getElementById('btn-speak')
    if (_msgAccueil && !_msgAccueil.paused) {
      _msgAccueil.pause(); _msgAccueil.currentTime = 0
      btn.textContent = '🔊 Message d\'accueil'; btn.classList.remove('speaking')
      return
    }
    var src = AGENT_WELCOME_AUDIO[_currentAgent]
    if (!src) {
      btn.textContent = '⚠️ Audio non configuré'
      setTimeout(function(){ btn.textContent = '🔊 Message d\'accueil' }, 2000)
      return
    }
    _msgAccueil = new Audio(src)
    _msgAccueil.play()
    btn.textContent = '⏸ Arrêter'; btn.classList.add('speaking')
    _msgAccueil.onended = function() { btn.textContent = '🔊 Message d\'accueil'; btn.classList.remove('speaking') }
    _msgAccueil.onerror = function() { btn.textContent = '🔊 Message d\'accueil'; btn.classList.remove('speaking') }
  }

  var _micRecognition = null, _micListening = false, _micFinalText = '', _micSendTimer = null
  var _inputWasVoice = false
  var MIC_SILENCE_MS = 3200  // pause tolérée avant envoi auto (parole lente / hésitations)

  function toggleMic() {
    var SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognitionAPI) {
      alert("La reconnaissance vocale n'est pas disponible sur ce navigateur. Essaie avec Chrome ou Edge.")
      return
    }
    var btn = document.getElementById('btn-mic')
    if (_micListening) {
      if (_micSendTimer) { clearTimeout(_micSendTimer); _micSendTimer = null }
      try { if (_micRecognition) _micRecognition.stop() } catch (e) {}
      var input = document.getElementById('chat-input')
      var text = ((input && input.value) || _micFinalText || '').trim()
      resetMicBtn()
      if (text) {
        if (input) input.value = ''
        sendMessageText(text, true)
      }
      return
    }

    _micFinalText = ''
    _micRecognition = new SpeechRecognitionAPI()
    _micRecognition.lang = 'fr-FR'
    _micRecognition.continuous = true
    _micRecognition.interimResults = true
    _micRecognition.maxAlternatives = 1

    _micRecognition.onstart = function() {
      _micListening = true
      if (!btn) return
      btn.textContent = '⏹'
      btn.style.background = 'rgba(255,75,110,0.15)'
      btn.style.borderColor = 'rgba(255,75,110,0.4)'
      btn.style.color = '#ff4b6e'
      btn.title = 'Cliquer pour terminer et envoyer'
    }

    _micRecognition.onresult = function(event) {
      var interim = ''
      for (var i = event.resultIndex; i < event.results.length; i++) {
        var piece = event.results[i][0].transcript
        if (event.results[i].isFinal) {
          _micFinalText = (_micFinalText + ' ' + piece).replace(/\s+/g, ' ').trim()
        } else {
          interim += piece
        }
      }
      var input = document.getElementById('chat-input')
      if (input) {
        input.value = (_micFinalText + (interim ? ' ' + interim : '')).replace(/\s+/g, ' ').trim()
        input.style.height = 'auto'
        input.style.height = Math.min(input.scrollHeight, 120) + 'px'
      }
      if (_micSendTimer) clearTimeout(_micSendTimer)
      _micSendTimer = setTimeout(function() {
        if (!_micListening) return
        var finalText = (_micFinalText || (input && input.value) || '').trim()
        try { if (_micRecognition) _micRecognition.stop() } catch (e) {}
        resetMicBtn()
        if (finalText) {
          if (input) input.value = ''
          sendMessageText(finalText, true)
        }
      }, MIC_SILENCE_MS)
    }

    _micRecognition.onerror = function(ev) {
      if (_micSendTimer) { clearTimeout(_micSendTimer); _micSendTimer = null }
      resetMicBtn()
    }
    _micRecognition.onend = function() {
      if (_micSendTimer) return
      resetMicBtn()
    }
    try {
      _micRecognition.start()
    } catch (e) {
      resetMicBtn()
      alert('Impossible de démarrer le micro. Réessaie.')
    }
  }

  function resetMicBtn() {
    _micListening = false
    var btn = document.getElementById('btn-mic')
    if (!btn) return
    btn.textContent = '🎤'
    btn.style.background = 'rgba(123,92,255,0.06)'
    btn.style.borderColor = 'rgba(123,92,255,0.2)'
    btn.style.color = 'var(--t3)'
    btn.title = 'Parler'
  }


  function cleanMarkdown(str) {
    return str
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:#c4b5fd;text-decoration:underline">$1</a>')
      // Filet de sécurité : une URL brute reste cliquable si un média n'a pas été transformé en player.
      .replace(/(^|\s)(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener" style="color:#c4b5fd;text-decoration:underline;overflow-wrap:anywhere">$2</a>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/^---+$/gm, '')
      .replace(/^#{1,6}\s+/gm, '')
      .replace(/^[-*]\s+/gm, '')
      .replace(/^>+\s*/gm, '')
      .replace(/`([^`]+)`/g, '$1')
      .trim()
  }

  function cleanForSpeech(str) {
    return str
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/---+/g, '')
      .replace(/#{1,6}\s+/g, '')
      .replace(/^>+\s*/gm, '')
      .replace(/\[IMAGE[\s\S]*?\]/gi, '')
      .replace(/\[(?:PROMPT|PARCHEMIN)\][\s\S]*?\[\/(?:PROMPT|PARCHEMIN)\]/gi, '')
      .replace(/\[(?:PROMPT|PARCHEMIN)_IMAGE[\s\S]*?\]/gi, '')
      .replace(/[✦💜🚀💎🌐📱⭐✓►▶🪞🌿🕯️🌙✨📖🔥👑😉📚📜]/gu, '')
      .replace(/<br>/g, ' ')
      .replace(/<[^>]+>/g, '')
      .replace(/\[VIDEO\s*:\s*[^\]\r\n]+\]/gi, '')
      .replace(/`([^`]+)`/g, '$1')
      .trim()
  }

  function escHtml(str) { var d = document.createElement('div'); d.textContent = str; return d.innerHTML }

  if (window.speechSynthesis) { try { window.speechSynthesis.getVoices() } catch (e) {} }
  