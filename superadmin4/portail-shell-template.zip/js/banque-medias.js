(()=>{'use strict';
const $=id=>document.getElementById(id);
let token=sessionStorage.getItem('nyxia_token')||new URLSearchParams(location.search).get('t')||'';
if(token)try{sessionStorage.setItem('nyxia_token',token)}catch(_){}
let kind='visual',filter='all';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');kind=b.dataset.kind;filter='all';document.querySelectorAll('.filter').forEach((x,i)=>x.classList.toggle('active',i===0));$('visualFilters').style.display=kind==='visual'?'flex':'none'}));
document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');filter=b.dataset.filter}));
async function search(){
  const q=$('query').value.trim();if(!q)return;
  $('status').textContent='Recherche dans le répertoire…';$('grid').innerHTML='';
  const path=kind==='sound'?'/api/media/sounds':'/api/media/images';
  const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,q,filter})});
  const d=await r.json().catch(()=>({}));if(!r.ok){$('status').textContent=d.error||'Recherche impossible.';$('grid').innerHTML='<div class="empty">Aucun résultat.</div>';return}
  const items=d.items||[];$('status').textContent=items.length+' résultat(s)'+(d.notice?' · '+d.notice:'');
  if(!items.length){$('grid').innerHTML='<div class="empty">Aucun résultat pour cette recherche.</div>';return}
  $('grid').innerHTML=items.map(x=>{
    let p=''; if(x.kind==='audio')p='<audio controls preload="none" src="'+esc(x.url)+'"></audio>';
    else if(x.kind==='video')p='<video controls preload="metadata" poster="'+esc(x.thumb||'')+'" src="'+esc(x.url)+'"></video>';
    else p='<img loading="lazy" src="'+esc(x.thumb||x.url)+'" alt="">';
    return '<article class="card"><div class="preview">'+p+'</div><div class="body"><div class="kind">'+esc(x.kind==='audio'?'Son':x.kind==='video'?'Vidéo':'Image')+'</div><div class="title">'+esc(x.title||'Ressource NyXia')+'</div><div class="actions"><a class="action" href="'+esc(x.url)+'" target="_blank" rel="noopener">Ouvrir</a><button class="action" data-copy="'+esc(x.url)+'">Copier le lien</button></div></div></article>'
  }).join('');
  document.querySelectorAll('[data-copy]').forEach(b=>b.addEventListener('click',async()=>{await navigator.clipboard.writeText(b.dataset.copy);const o=b.textContent;b.textContent='✓ Copié';setTimeout(()=>b.textContent=o,1200)}))
}
$('searchBtn').addEventListener('click',search);$('query').addEventListener('keydown',e=>{if(e.key==='Enter')search()});
})();