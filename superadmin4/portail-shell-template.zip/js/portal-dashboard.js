
(()=>{const token=new URLSearchParams(location.search).get('t')||sessionStorage.getItem('nyxia_token')||'';if(token)sessionStorage.setItem('nyxia_token',token);
const pages=window.NYXIA_PAGES||{},frame=document.getElementById('frame'),hall=document.getElementById('hall');
function openPage(k){if(k==='hall'){frame.hidden=true;hall.hidden=false;return}const p=pages[k];if(!p)return;hall.hidden=true;frame.hidden=false;frame.src=p+(p.includes('?')?'&':'?')+'t='+encodeURIComponent(token)}
document.querySelectorAll('[data-page]').forEach(x=>x.onclick=()=>{document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));x.classList.add('active');openPage(x.dataset.page)});
document.querySelectorAll('[data-open]').forEach(x=>x.onclick=()=>openPage(x.dataset.open));
document.querySelectorAll('[data-agent-card]').forEach(x=>x.onclick=()=>openPage(x.dataset.agentCard));
document.getElementById('logout').onclick=()=>{sessionStorage.removeItem('nyxia_token');location.href='/login.html'};
try{const u=JSON.parse(sessionStorage.getItem('nyxia_user')||'{}');if(u.firstname)document.getElementById('hello').textContent='Bonjour '+u.firstname}catch(_){}
if(!token)location.replace('/login.html')})();
