(()=>{'use strict';

let token=sessionStorage.getItem('nyxia_token')||new URLSearchParams(location.search).get('t')||'';
if(token)sessionStorage.setItem('nyxia_token',token);

const pages=window.NYXIA_PORTAL_PAGES||{};
let current='';

const q=s=>document.querySelector(s);

function syncAtelierState(key){
  const wrap=q('#portal-atelier');
  const menu=q('#portal-atelier-menu');
  const trigger=q('#portal-atelier-trigger');
  if(!wrap||!menu||!trigger)return;

  const active=!!menu.querySelector('[data-page-key="'+CSS.escape(key)+'"]');
  wrap.classList.toggle('has-active',active);

  if(active){
    wrap.classList.add('open');
    trigger.setAttribute('aria-expanded','true');
  }
}

function openPage(key){
  const url=pages[key];
  if(!url)return;

  current=key;

  document.querySelectorAll('.nav-item').forEach(el=>{
    el.classList.toggle('active',el.dataset.pageKey===key);
  });

  syncAtelierState(key);

  let frame=q('#nyxia-frame');
  if(!frame){
    frame=document.createElement('iframe');
    frame.id='nyxia-frame';
    frame.title='Portail NyXia';
    frame.setAttribute('allow','microphone; autoplay; clipboard-write');
    q('#page-container').replaceChildren(frame);
  }

  frame.src=url+(url.includes('?')?'&':'?')+'t='+encodeURIComponent(token);
  closeMobileMenu();
}

function toggleAtelier(){
  const wrap=q('#portal-atelier');
  const trigger=q('#portal-atelier-trigger');
  if(!wrap||!trigger)return;
  const open=!wrap.classList.contains('open');
  wrap.classList.toggle('open',open);
  trigger.setAttribute('aria-expanded',open?'true':'false');
}

function openMobileMenu(){
  const aside=q('aside'),backdrop=q('#mobile-menu-backdrop');
  if(!aside)return;
  aside.classList.add('mobile-open');
  backdrop?.classList.add('mobile-open');
  document.body.style.overflow='hidden';
}

function closeMobileMenu(){
  const aside=q('aside'),backdrop=q('#mobile-menu-backdrop');
  aside?.classList.remove('mobile-open');
  backdrop?.classList.remove('mobile-open');
  document.body.style.overflow='';
}

function toggleMobileMenu(){
  const aside=q('aside');
  if(!aside)return;
  aside.classList.contains('mobile-open')?closeMobileMenu():openMobileMenu();
}

window.openAgentTab=openPage;
window.toggleAtelier=toggleAtelier;
window.toggleMobileMenu=toggleMobileMenu;
window.closeMobileMenu=closeMobileMenu;

async function init(){
  if(!token){
    location.href='/login.html';
    return;
  }

  try{
    const r=await fetch('/api/check-auth',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({token})
    });
    const d=await r.json();
    if(!d.valid){
      location.href='/login.html';
      return;
    }
    const n=q('#user-firstname');
    if(n)n.textContent=d.firstname||'';
  }catch(_){}

  document.querySelectorAll('[data-page-key]').forEach(el=>{
    el.addEventListener('click',()=>openPage(el.dataset.pageKey));
  });

  q('#portal-atelier-trigger')?.addEventListener('click',toggleAtelier);
  q('#mobile-menu-btn')?.addEventListener('click',toggleMobileMenu);
  q('#mobile-menu-backdrop')?.addEventListener('click',closeMobileMenu);

  q('#logout-btn')?.addEventListener('click',async()=>{
    try{
      await fetch('/api/logout',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({token})
      });
    }catch(_){}
    sessionStorage.removeItem('nyxia_token');
    location.href='/login.html';
  });

  openPage(window.NYXIA_DEFAULT_AGENT||Object.keys(pages)[0]||'');
}

document.addEventListener('DOMContentLoaded',init);
})();